<?php
require('db.php');

$response = array();

$query_mca = "SELECT COUNT(*) as count FROM MCA";
$result_mca = mysqli_query($con, $query_mca);
$row_mca = mysqli_fetch_assoc($result_mca);
$response['mca_count'] = $row_mca['count'];

$query_btech = "SELECT COUNT(*) as count FROM B_Tech";
$result_btech = mysqli_query($con, $query_btech);
$row_btech = mysqli_fetch_assoc($result_btech);
$response['btech_count'] = $row_btech['count'];

$query_mtech = "SELECT COUNT(*) as count FROM M_Tech";
$result_mtech = mysqli_query($con, $query_mtech);
$row_mtech = mysqli_fetch_assoc($result_mtech);
$response['mtech_count'] = $row_mtech['count'];

$query_faculty = "SELECT COUNT(*) as count FROM admin_faculty";
$result_faculty = mysqli_query($con, $query_faculty);
$row_faculty = mysqli_fetch_assoc($result_faculty);
$response['faculty_count'] = $row_faculty['count'];

echo json_encode($response);
?>
