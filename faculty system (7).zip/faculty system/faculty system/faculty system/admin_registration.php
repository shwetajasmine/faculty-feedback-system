<?php
require('db.php');

// If form submitted, insert values into the database.
if (isset($_REQUEST['username'])) {
    // removes backslashes
    $username = stripslashes($_REQUEST['username']);
    //escapes special characters in a string
    $username = mysqli_real_escape_string($con, $username);
    $email = stripslashes($_REQUEST['email']);
    $email = mysqli_real_escape_string($con, $email);
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con, $password);
    $trn_date = date("Y-m-d H:i:s");
    $query = "INSERT into `admin_login` (username, password, email, trn_date) VALUES ('$username', '".md5($password)."', '$email', '$trn_date')";
    $result = mysqli_query($con, $query);
    if ($result) {
        // Redirect to registration page with success parameter
        header("Location: admin_registration.php?success=true");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .error {
            color: red;
            font-size: 0.8em;
        }
    </style>
    <style>
        a {
            text-decoration: none;
        }


        .container {
            position: relative;
            width: 100%;
            min-height: 100vh;
            background: #fff;
            overflow: hidden;
        }

        .container::before {
            content: "";
            position: absolute;
            width: 2800px;
            height: 2000px;
            border-radius: 50%;
            background: linear-gradient(-45deg, #b538d1, #d672ec);
            right: 48%;
            -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
            z-index: 6;
            -webkit-transition: 1.8s ease-in-out;
            transition: 1.8s ease-in-out;
        }

        .container__forms {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
        }

        .container__panels {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    display: -ms-grid;
    display: grid;
    -ms-grid-columns: 1fr 1fr; /* Correct syntax for IE */
    grid-template-columns: repeat(2, 1fr); /* Standard syntax */
}

        form {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 0 5rem;
            overflow: hidden;
            transition: 0.2s 0.7s ease-in-out;
        }

        .form {
            position: absolute;
            top: 50%;
            left: 75%;
            -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%);
            width: 50%;
            display: -ms-grid;
            display: grid;
            -ms-grid-columns: 1fr;
            grid-template-columns: 1fr;
            z-index: 5;
            -webkit-transition: 1s 0.7s ease-in-out;
            transition: 1s 0.7s ease-in-out;
        }

        .form-group {
            width: 100%;
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* .form-control{
            border-radius: 10px;
        } */
        .form__title {
            font-size: 2.2rem;
            color: #444;
            margin-bottom: 20px;
        }

        .form__submit {
            width: 9.375rem;
            height: 3.0625rem;
            border: none;
            outline: none;
            border-radius: 3.0625rem;
            cursor: pointer;
            background-color: #b538d1;
            color: #fff;
            text-transform: uppercase;
            font-weight: 600;
            margin: 10px 0;
            -webkit-transition: 0.5s;
            transition: 0.5s;
        }

        .form__submit:hover {
            background-color: #5a1369;
        }

        .panel {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -webkit-box-align: end;
            -ms-flex-align: end;
            align-items: flex-end;
            -ms-flex-pack: distribute;
            justify-content: space-around;
            text-align: center;
            z-index: 7;
        }

        .panel__content {
            color: #fff;
            -webkit-transition: 0.9s 0.6s ease-in-out;
            transition: 0.9s 0.6s ease-in-out;
        }

        .panel__left {
            pointer-events: all;
            padding: 3rem 17% 2rem 12%;
        }

        .panel__right {
            pointer-events: none;
            padding: 3rem 12% 2rem 17%;
        }

        .panel__title {
            font-weight: 600;
            line-height: 1;
            font-size: 1.5rem;
        }

        .panel__image {
            width: 100%;
            -webkit-transition: 1.1s 0.4s ease-in-out;
            transition: 1.1s 0.4s ease-in-out;
        }

        .btn {
            border: none;
            outline: none;
            border-radius: 3.0625rem;
            cursor: pointer;
            color: #fff;
            text-transform: uppercase;
            font-weight: 600;
            -webkit-transition: 0.5s;
            transition: 0.5s;
            margin: 0;
            background: none;
            border: 2px solid #fff;
            width: 130px;
            height: 41px;
            font-size: 0.8rem;
        }

        .btn:hover a {
            color: black !important;
            transition: 0.5s ease-in-out;
        }

        @media (max-width: 870px) {
            .container {
                min-height: 800px;
                height: 100vh;
            }

            .container::before {
                width: 1500px;
                height: 1500px;
                left: 30%;
                bottom: 68%;
                -webkit-transform: translateX(-50%);
                transform: translateX(-50%);
                right: initial;
                top: initial;
                -webkit-transition: 2s ease-in-out;
                transition: 2s ease-in-out;
            }

            .form {
                width: 100%;
                left: 50%;
                top: 95%;
                -webkit-transform: translate(-50%, -100%);
                transform: translate(-50%, -100%);
                -webkit-transition: 1s 0.8s ease-in-out;
                transition: 1s 0.8s ease-in-out;
            }

            .container__panels {
                -ms-grid-columns: 1fr;
                grid-template-columns: 1fr;
                -ms-grid-rows: 1fr 2fr 1fr;
                grid-template-rows: 1fr 2fr 1fr;
            }

            .panel {
                -webkit-box-orient: horizontal;
                -webkit-box-direction: normal;
                -ms-flex-direction: row;
                flex-direction: row;
                -ms-flex-pack: distribute;
                justify-content: space-around;
                -webkit-box-align: center;
                -ms-flex-align: center;
                align-items: center;
                padding: 2.5rem 8%;
            }

            .panel__left {
                -ms-grid-row: 1;
                -ms-grid-row-span: 1;
                grid-row: 1 / 2;
            }

            .panel__right {
                -ms-grid-row: 3;
                -ms-grid-row-span: 1;
                grid-row: 3 / 4;
            }

            .panel__image {
                width: 200px;
                -webkit-transition: 0.9s 0.6s ease-in-out;
                transition: 0.9s 0.6s ease-in-out;
            }

            .panel__content {
                padding-right: 15%;
                -webkit-transition: 0.9s 0.8s ease-in-out;
                transition: 0.9s 0.8s ease-in-out;
            }

            .panel__title {
                font-size: 1.2rem;
            }

            .panel__paragraph {
                font-size: 0.7rem;
                padding: 0.5rem 0;
            }

            .panel__right .panel__content,
            .panel__right .panel__image {
                -webkit-transform: translateY(300px);
                transform: translateY(300px);
            }

            .btn {
                width: 6.875rem;
                height: 2.187rem;
                font-size: 0.7rem;
            }

            .container.sign-up-mode::before {
                -webkit-transform: translate(-50%, 100%);
                transform: translate(-50%, 100%);
                bottom: 32%;
                right: initial;
            }

            .container.container.sign-up-mode .panel__left .panel__image,
            .container.container.sign-up-mode .panel__left .panel__content {
                -webkit-transform: translateY(-300px);
                transform: translateY(-300px);
            }

            .container.sign-up-mode .form {
                top: 5%;
                -webkit-transform: translate(-50%, 0);
                transform: translate(-50%, 0);
                left: 50%;
            }
        }

        @media (max-width: 570px) {
            form {
                padding: 0 1.5rem;
            }

            .panel__image {
                display: none;
            }

            .panel__content {
                padding: 0.5rem 1rem;
            }

            .container::before {
                bottom: 72%;
                left: 50%;
            }

            .container.sign-up-mode::before {
                bottom: 28%;
                left: 50%;
            }
        }
    </style>

</head>

<body>

<div class="container">
        <div class="container__forms">
            <div class="form">

                <div class="">
                    <div class="text-center">
                        <h3 class="form__title">Admin Registration</h3>
                        <div id="successMessage" class="alert alert-success" style="display: none;">You are registered
                            successfully.</div>
                    </div>
                    <div class="">
                        <form name="registration" action="" method="post">
                            <div class="form-group">

                                <input type="text" name="username" id="username" class="form-control"
                                    placeholder="Username"  />
                                <span id="usernameError" class="error"></span>
                            </div>
                            <div class="form-group">

                                <input type="email" name="email" id="email" class="form-control"
                                    placeholder="Email"/>
                                <span id="emailError" class="error"></span>
                            </div>
                            <div class="form-group">

                                <input type="password" name="password" id="password" class="form-control"
                                    placeholder="Password"  />
                                <span id="passwordError" class="error"></span>
                            </div>
                            <div class="form-group">
                                <button type="submit" name="submit" class="form__submit">Register</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="container__panels">
            <div class="panel panel__left">
                <div class="panel__content">
                    <h3 class="panel__title">Already Have an Account?</h3>
                    <p class="panel__paragraph">
                        Please Login below
                    </p>
                    <button class="btn btn-transparent">
                        <a href="admin_login.php" class="text-white" style="text-decoration:none">Login</a>
                    </button>
                </div>
                <img class="panel__image"
                    src="https://stories.freepiklabs.com/storage/11588/market-launch-amico-2628.png" alt="" />
            </div>

        </div>
    </div>

    <!------->

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>



<script>
    $(document).ready(function() {
        // Function to validate username
        $('#username').on('input', function() {
            var username = $(this).val();
            var usernameError = $('#usernameError');
            if (!username) {
                usernameError.text("Username is required");
            } else if (username.length < 4) {
                usernameError.text("Username must be at least 4 characters");
            } else {
                usernameError.text("");
            }
        });

        // Function to validate email
        $('#email').on('input', function() {
            var email = $(this).val();
            var emailError = $('#emailError');
            if (!email) {
                emailError.text("Email is required");
            } else if (!/\S+@\S+\.\S+/.test(email)) {
                emailError.text("Invalid email address");
            } else {
                emailError.text("");
            }
        });

        // Function to validate password
        $('#password').on('input', function() {
            var password = $(this).val();
            var passwordError = $('#passwordError');
            var uppercase = /[A-Z]/.test(password);
            var lowercase = /[a-z]/.test(password);
            var number = /\d/.test(password);
            var specialChars = /[^\w\s]/.test(password);

            if (!password) {
                passwordError.text("Password is required");
            } else if (!uppercase) {
                passwordError.text("Password must contain at least one uppercase letter");
            } else if (!lowercase) {
                passwordError.text("Password must contain at least one lowercase letter");
            } else if (!number) {
                passwordError.text("Password must contain at least one number");
            } else if (!specialChars) {
                passwordError.text("Password must contain at least one special character");
            } else if (password.length < 8) {
                passwordError.text("Password must be at least 8 characters");
            } else {
                passwordError.text("");
            }
        });

        // Show success message if redirected with success parameter
        const urlParams = new URLSearchParams(window.location.search);
        const successParam = urlParams.get('success');
        if (successParam === 'true') {
            $('#successMessage').show();
        }
    });
</script>
</body>
</html>
