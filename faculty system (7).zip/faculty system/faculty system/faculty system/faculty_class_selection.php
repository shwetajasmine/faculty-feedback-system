<?php
require('db.php');

// Function to calculate average rating
function calculateAverageRating($con, $faculty_id, $class_id) {
    $query = "SELECT AVG(rating) AS average_rating FROM student_feedbacks WHERE faculty_id = '$faculty_id' AND class = '$class_id'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['average_rating'];
}

// Check if a faculty is selected
if(isset($_POST['faculty_id'])) {
    $faculty_id = $_POST['faculty_id'];

    // Fetch faculty details
    $faculty_query = "SELECT * FROM admin_faculty WHERE id = '$faculty_id'";
    $faculty_result = mysqli_query($con, $faculty_query);
    $faculty_row = mysqli_fetch_assoc($faculty_result);

    // Fetch distinct classes related to the selected faculty from the database
    $class_query = "SELECT DISTINCT class_1, class_2, class_3 FROM admin_faculty WHERE id = '$faculty_id'";
    $class_result = mysqli_query($con, $class_query);

    // Check for query execution errors
    if (!$class_result) {
        // Handle the error, for example:
        die("Error fetching classes for the selected faculty: " . mysqli_error($con));
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Class</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="custom.css">
    <!-- Chart.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
    <style>
        /* Custom CSS for sidebar */
        .sidebar {
            background-color: #333;
            color: #fff;
            height: 100vh;
        }
        .menu-item {
            padding: 10px;
            border-bottom: 1px solid #555;
        }
        .menu-item:hover {
            background-color: #555;
        }

        /* Custom CSS for feedback table */
        .feedback-table {
            margin-top: 20px;
        }

        /* Custom CSS for analytics charts */
        .chart-container {
            margin-top: 20px;
            height: 400px;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="faculty_dashboard.php"> Faculty Selection</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="startpage.php">Homepage</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar with menu items -->
            <div class="col-md-3 sidebar">
                <h3 class="text-center">Dashboard Methods</h3>
                <div class="menu-item">
                    <h5>MCA</h5>
                    <form method="post" action="">
                        <input type="hidden" name="faculty_id" value="<?php echo $faculty_id; ?>">
                        <input type="hidden" name="class_id" value="MCA">
                        <button type="submit" class="btn btn-primary btn-block">MCA</button>
                    </form>
                </div>
                <div class="menu-item">
                    <h5>B Tech</h5>
                    <form method="post" action="">
                        <input type="hidden" name="faculty_id" value="<?php echo $faculty_id; ?>">
                        <input type="hidden" name="class_id" value="B-Tech">
                        <button type="submit" class="btn btn-primary btn-block">B Tech</button>
                    </form>
                </div>
                <div class="menu-item">
                    <h5>M Tech</h5>
                    <form method="post" action="">
                        <input type="hidden" name="faculty_id" value="<?php echo $faculty_id; ?>">
                        <input type="hidden" name="class_id" value="M-Tech">
                        <button type="submit" class="btn btn-primary btn-block">M Tech</button>
                    </form>
                </div>
                <div class="menu-item">
                    <h5>Analytics</h5>
                    <form method="post" action="">
                        <input type="hidden" name="faculty_id" value="<?php echo $faculty_id; ?>">
                        <input type="hidden" name="class_id" value="Analytics">
                        <button type="submit" class="btn btn-primary btn-block">Analytics</button>
                    </form>
                </div>
            </div>
            <!-- Feedback display -->
            <div class="col-md-9">
                <div class="container feedback-table">
                    <h2 class="mt-4">Feedback for <?php echo $faculty_row['facultyname']; ?></h2>
                    <?php 
                    // Check if feedback_result is a valid mysqli_result object
                    if(isset($_POST['class_id']) && $_POST['class_id'] !== 'Analytics') {
                        $class_id = $_POST['class_id'];

                        // Fetch feedback for the selected faculty and class
                        $feedback_query = "SELECT * FROM student_feedbacks WHERE faculty_id = '$faculty_id' AND class = '$class_id'";
                        $feedback_result = mysqli_query($con, $feedback_query);

                        // Check for query execution errors
                        if (!$feedback_result) {
                            // Handle the error, for example:
                            die("Error fetching feedback data: " . mysqli_error($con));
                        }

                        if(mysqli_num_rows($feedback_result) > 0): ?>
                            <table class="table table-bordered table-striped mt-2 border-dark">
                                <thead class="thead-dark">
                                    <tr align="center">
                                        <th>S.No</th>
                                        <th>Rating</th>
                                        <th>Feedback</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $serial_number = 1; // Initialize serial number counter
                                    while($feedback_row = mysqli_fetch_assoc($feedback_result)):
                                    ?>
                                    <tr>
                                        <td align="center"><?php echo $serial_number++; ?></td>
                                        <td align="center"><?php echo $feedback_row['rating']; ?></td>
                                        <td><?php echo $feedback_row['feedback']; ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="alert alert-info" role="alert">No feedback available for this faculty and class.</div>
                        <?php endif;
                    } else if(isset($_POST['class_id']) && $_POST['class_id'] === 'Analytics') { ?>
                        <!-- Chart.js for Class Ratings Analytics -->
                        <h2 class="mt-4">Class Ratings Analytics</h2>
                        <canvas id="ratingsChart"></canvas>
                        <script>
                            var ctx = document.getElementById('ratingsChart').getContext('2d');
                            var ratingsChart = new Chart(ctx, {
                                type: 'bar',
                                data: {
                                    labels: ['MCA', 'B Tech', 'M Tech'],
                                    datasets: [{
                                        label: 'Average Ratings',
                                        data: [
                                            <?php
                                            // Calculate average ratings for each class
                                            $mca_rating = calculateAverageRating($con, $faculty_id, 'MCA');
                                            $btech_rating = calculateAverageRating($con, $faculty_id, 'B-Tech');
                                            $mtech_rating = calculateAverageRating($con, $faculty_id, 'M-Tech');
                                            
                                            echo $mca_rating . ', ' . $btech_rating . ', ' . $mtech_rating;
                                            ?>
                                        ],
                                        backgroundColor: [
                                            'rgba(255, 99, 132, 0.2)',
                                            'rgba(54, 162, 235, 0.2)',
                                            'rgba(255, 206, 86, 0.2)'
                                        ],
                                        borderColor: [
                                            'rgba(255, 99, 132, 1)',
                                            'rgba(54, 162, 235, 1)',
                                            'rgba(255, 206, 86, 1)'
                                        ],
                                        borderWidth: 1
                                    }]
                                },
                                options: {
                                    scales: {
                                        y: {
                                            beginAtZero: true
                                        }
                                    }
                                }
                            });
                        </script>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
}
?>
