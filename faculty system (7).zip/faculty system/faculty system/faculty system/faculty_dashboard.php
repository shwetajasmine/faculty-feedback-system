<?php
require('db.php');

// Fetch distinct faculty from the database
$faculty_query = "SELECT * FROM admin_faculty";
$faculty_result = mysqli_query($con, $faculty_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Faculty</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-4">Select Faculty</h2>
        
        <!-- Faculty selection form -->
        <form method="post" action="faculty_class_selection.php">
            <div class="form-group">
                <label for="faculty_id">Select Faculty:</label>
                <select name="faculty_id" id="faculty_id" class="form-control">
                    <?php while($faculty_row = mysqli_fetch_assoc($faculty_result)): ?>
                        <option value="<?php echo $faculty_row['id']; ?>"><?php echo $faculty_row['facultyname']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <input type="submit" class="btn btn-primary" value="Next">
        </form>
    </div>
</body>
</html>
