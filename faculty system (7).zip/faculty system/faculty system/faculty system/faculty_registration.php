<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Registration</title>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
            width: 500px;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        .form-container h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        .form-container form {
            max-width: 550px;
            margin: 0 auto;
        }
        .form-container .btn {
            margin-top: 20px;
        }
        .form-group input[type="text"] {
            width: 100%;
        }
        .invalid-feedback {
            color: red;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-container">
        <h1>Registration</h1>
        <?php
        require('db.php');
        // If form submitted, insert values into the database.
        if (isset($_REQUEST['submit'])){
            $faculty_id = stripslashes($_POST['faculty_id']);
            $faculty_id = mysqli_real_escape_string($con,$faculty_id); 
            $faculty_name = stripslashes($_POST['faculty_name']);
            $faculty_name = mysqli_real_escape_string($con,$faculty_name);
            $trn_date = date("Y-m-d H:i:s");
            $query = "INSERT into `faculty_login` (faculty_id, faculty_name, trn_date) VALUES ('$faculty_id', '$faculty_name', '$trn_date')";
            $result = mysqli_query($con,$query);
            if($result){
                echo "<div class='alert alert-success text-center'>You are registered successfully.<br>Click here to <a href='faculty_login.php'>Login</a></div>";
            }
        }
        ?>
        <form name="registration" id="registrationForm" action="" method="post" novalidate>
            <div class="form-group">
                <input type="text" name="faculty_id" placeholder="Faculty Id" required />
                <div class="invalid-feedback">Please enter Faculty ID.</div>
            </div>
            <div class="form-group">
                <input type="text" name="faculty_name" placeholder="Faculty Name" required />
                <div class="invalid-feedback">Please enter Faculty Name.</div>
            </div>
            <input type="submit" class="btn btn-primary btn-block" name="submit" value="Register" />
        </form>
    </div>
</div>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // Add event listener to the form
    document.getElementById("registrationForm").addEventListener("submit", function(event) {
        // Check if the form is valid
        if (this.checkValidity() === false) {
            event.preventDefault(); // Prevent form submission
            event.stopPropagation(); // Prevent event propagation
        }
        this.classList.add('was-validated'); // Add Bootstrap's validation classes
    }, false);
</script>
</body>
</html>
