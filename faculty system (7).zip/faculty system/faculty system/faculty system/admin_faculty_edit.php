<?php
require('db.php');

// Check if ID is provided in the request
if(isset($_REQUEST['id'])) {
    $id = $_REQUEST['id'];

    // Fetch the record for editing
    $query = "SELECT * FROM admin_faculty WHERE id='$id'"; 
    $result = mysqli_query($con, $query) or die(mysqli_error($con));
    $row = mysqli_fetch_assoc($result);

    // Check if the form is submitted
    if(isset($_POST['submit'])) {
        $facultyname = $_POST['facultyname'];
        $facultyid = $_POST['facultyid'];
        $email = $_POST['email'];
        $phoneno = $_POST['phoneno'];
        $semester = $_POST['semester'];
        $class_1 = $_POST['class_1'];
        $subject_1 = $_POST['subject_1'];
        $subjectcode_1 = $_POST['subjectcode_1'];
        $class_2 = $_POST['class_2'];
        $subject_2 = $_POST['subject_2'];
        $subjectcode_2 = $_POST['subjectcode_2'];
        $class_3 = $_POST['class_3'];
        $subject_3 = $_POST['subject_3'];
        $subjectcode_3 = $_POST['subjectcode_3'];
        
        // Update query
        $update_query = "UPDATE admin_faculty SET facultyname='$facultyname', facultyid='$facultyid', email='$email', phoneno='$phoneno', semester='$semester', class_1='$class_1', subject_1='$subject_1', subjectcode_1='$subjectcode_1', class_2='$class_2', subject_2='$subject_2', subjectcode_2='$subjectcode_2', class_3='$class_3', subject_3='$subject_3', subjectcode_3='$subjectcode_3' WHERE id='$id'";
        
        // Perform the update query
        $update_result = mysqli_query($con, $update_query);

        // Check if the update query was successful
        if($update_result) {
            $status = "Record Updated Successfully. </br></br><a href='admin_facultyview.php'>View Updated Record</a>";
        } else {
            $status = "Error: " . mysqli_error($con);
        }

        echo '<p style="color:#FF0000;">'.$status.'</p>';
    }
} else {
    // Redirect if ID is not provided
    header("Location: admin_facultyview.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Edit Faculty Record</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="css/Adminform.css" />
<style>
    /* Add custom styles here */
    .form-container {
        margin-top: 50px;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 10px;
    }
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_facultyview.php">View Faculty</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="admin_dashboard.php">Dashboard</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php
include('admin_sidebar.php');
?>
<div class="content">
        <div class="container">
            <div class="glass-card">
<h1> Update Faculty Record</h1>

   
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="form-container">
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                    <a class="navbar-brand" href="#">Faculty Form</a>
                </nav>
                <form name="form" method="post" action=""> 
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>" />
                    <div class="form-group">
                        <input type="text" name="facultyname" class="form-control" placeholder="Enter Faculty Name" value="<?php echo $row['facultyname']; ?>" required />
                    </div>
                    <div class="form-group">
                        <input type="text" name="facultyid" class="form-control" placeholder="Enter Faculty ID" value="<?php echo $row['facultyid']; ?>" required />
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" class="form-control" placeholder="Enter Email" value="<?php echo $row['email']; ?>" required />
                    </div>
                    <div class="form-group">
                        <input type="text" name="phoneno" class="form-control" placeholder="Enter Phone Number" value="<?php echo $row['phoneno']; ?>" required />
                    </div>
                    <div class="form-group">
    <select name="semester" id="semester" class="form-control" required>
        <option value="">Choose the Semester</option>
        <option value="Odd Semester" <?php if($row['semester'] == 'Odd Semester') echo 'selected'; ?>>Odd Semester</option>
        <option value="Even Semester" <?php if($row['semester'] == 'Even Semester') echo 'selected'; ?>>Even Semester</option>
    </select>
                     </div>
                     <div class="form-group">
                        <select name="semestergrp" id="semestergrp" class="form-control" required>
                            <option value="">Choose the Semester</option>
                            <option value="I" <?php if($row['semestergrp'] == 'I') echo 'selected'; ?>>I Semester</option>
                            <option value="II" <?php if($row['semestergrp'] == 'II') echo 'selected'; ?>>II Semester</option> 
                            <option value="III" <?php if($row['semestergrp'] == 'III') echo 'selected'; ?>>III Semester</option>
                            <option value="IV" <?php if($row['semestergrp'] == 'IV') echo 'selected'; ?>>IV Semester</option>
                            <option value="V" <?php if($row['semestergrp'] == 'V') echo 'selected'; ?>>V Semester</option>
                            <option value="VI" <?php if($row['semestergrp'] == 'VI') echo 'selected'; ?>>VI Semester</option>
                        </select>
                    </div> 
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="class_1">Class 1:</label>
                            <input type="text" name="class_1" class="form-control" placeholder="Enter Class 1" value="<?php echo $row['class_1']; ?>" required />

                        </div>
                        <div class="form-group col-md-4">
                            <label for="subject_1">Subject 1:</label>
                            <select id="subject_1" name="subject_1" class="form-control">
                                <option value="">Select the Subject</option>
                                <option value="Python" <?php if($row['subject_1'] == 'Python') echo 'selected'; ?>>Python</option>
                                <option value="Internet Of Things" <?php if($row['subject_1'] == 'Internet Of Things') echo 'selected'; ?>>Internet Of Things</option>
                                <option value="Computer Networks" <?php if($row['subject_1'] == 'Computer Networks') echo 'selected'; ?>>Computer Networks</option>
                                <option value="None" <?php if($row['subject_1'] == 'None') echo 'selected'; ?>>None</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subjectcode_1">SubjectCode 1:</label>
                            <select id="subjectcode_1" name="subjectcode_1" class="form-control">
                                <option value="">Select the SubjectCode</option>
                                <option value="PY102" <?php if($row['subjectcode_1'] == 'PY102') echo 'selected'; ?>>PY102</option>
                                <option value="IOT34" <?php if($row['subjectcode_1'] == 'IOT34') echo 'selected'; ?>>IOT34</option>
                                <option value="CN457" <?php if($row['subjectcode_1'] == 'CN457') echo 'selected'; ?>>CN457</option>
                                <option value="None" <?php if($row['subjectcode_1'] == 'None') echo 'selected'; ?>>None</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="class_2">Class 2:</label>
                            <input type="text" name="class_2" class="form-control" placeholder="Enter Class 2" value="<?php echo $row['class_2']; ?>" required />

                        </div>
                        <div class="form-group col-md-4">
                            <label for="subject_2">Subject 2:</label>
                            <select id="subject_2" name="subject_2" class="form-control">
                                <option value="">Select the Subject</option>
                                <option value="Python" <?php if($row['subject_2'] == 'Python') echo 'selected'; ?>>Python</option>
                                <option value="Internet Of Things" <?php if($row['subject_2'] == 'Internet Of Things') echo 'selected'; ?>>Internet Of Things</option>
                                <option value="Computer Networks" <?php if($row['subject_2'] == 'Computer Networks') echo 'selected'; ?>>Computer Networks</option>
                                <option value="None" <?php if($row['subject_2'] == 'None') echo 'selected'; ?>>None</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subjectcode_2">SubjectCode 2:</label>
                            <select id="subjectcode_2" name="subjectcode_2" class="form-control">
                                <option value="">Select the SubjectCode</option>
                                <option value="PY102" <?php if($row['subjectcode_2'] == 'PY102') echo 'selected'; ?>>PY102</option>
                                <option value="IOT34" <?php if($row['subjectcode_2'] == 'IOT34') echo 'selected'; ?>>IOT34</option>
                                <option value="CN457" <?php if($row['subjectcode_2'] == 'CN457') echo 'selected'; ?>>CN457</option>
                                <option value="None" <?php if($row['subjectcode_2'] == 'None') echo 'selected'; ?>>None</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="class_3">Class 3:</label>
                            <input type="text" name="class_3" class="form-control" placeholder="Enter Class 3" value="<?php echo $row['class_3']; ?>" required />

                        </div>
                        <div class="form-group col-md-4">
                            <label for="subject_3">Subject 3:</label>
                            <select id="subject_3" name="subject_3" class="form-control">
                                <option value="">Select the Subject</option>
                                <option value="Python" <?php if($row['subject_3'] == 'Python') echo 'selected'; ?>>Python</option>
                                <option value="Internet Of Things" <?php if($row['subject_3'] == 'Internet Of Things') echo 'selected'; ?>>Internet Of Things</option>
                                <option value="Computer Networks" <?php if($row['subject_3'] == 'Computer Networks') echo 'selected'; ?>>Computer Networks</option>
                                <option value="None" <?php if($row['subject_3'] == 'None') echo 'selected'; ?>>None</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subjectcode_3">SubjectCode 3:</label>
                            <select id="subjectcode_3" name="subjectcode_3" class="form-control">
                                <option value="">Select the SubjectCode</option>
                                <option value="PY102" <?php if($row['subjectcode_3'] == 'PY102') echo 'selected'; ?>>PY102</option>
                                <option value="IOT34" <?php if($row['subjectcode_3'] == 'IOT34') echo 'selected'; ?>>IOT34</option>
                                <option value="CN457" <?php if($row['subjectcode_3'] == 'CN457') echo 'selected'; ?>>CN457</option>
                                <option value="None" <?php if($row['subjectcode_3'] == 'None') echo 'selected'; ?>>None</option>
                            </select>
                        </div>
                    </div>
                    <!-- Repeat similar structure for other classes and subjects -->
    
                    <div class="form-group text-center">
                            <input name="submit" type="submit" class="btn btn-primary" />
                            
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
