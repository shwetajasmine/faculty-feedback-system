<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        :root {
        
            --box1-gradient: linear-gradient(135deg, #D8B5FF , #1EAE98);
            --box2-gradient: linear-gradient(135deg, #EE9CA7 , #FFDDE1);
            --box3-gradient: linear-gradient(135deg, #02AABD , #00CDAC);
            --box4-gradient: linear-gradient(135deg, #BFF098 , #6FD6FF);
            --text-color: #ffffff;
            --bg-color: #f4f6f9;
            --tran-05: 0.5s;
        }

        body {
            background-color: var(--bg-color);
            font-family: 'Rubik', sans-serif;
        }

        .navbar {
            margin-bottom: 10px;
        }

        .dash-content .boxes {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .dash-content .boxes .box {
            display: flex;
            flex-direction: column;
            align-items: center;
            border-radius: 12px;
            width: calc(100% / 4 - 15px);
            padding: 30px 20px;
            background: var(--box1-gradient);
            color:black;
            font-weight: 700;
            transition: var(--tran-05);
            margin-bottom: 20px;
            text-align: center;
            cursor: pointer;
            transform: scale(1);
        }

        .dash-content .boxes .box:hover {
            transform: scale(1.1);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }

        .dash-content .boxes .box:nth-child(2) {
            background: var(--box2-gradient);
        }

        .dash-content .boxes .box:nth-child(3) {
            background: var(--box3-gradient);
        }

        .dash-content .boxes .box:nth-child(4) {
            background: var(--box4-gradient);
        }

        .dash-content .boxes .box h5 {
            margin-bottom: 15px;
            font-size: 24px;
        }

        .dash-content .boxes .box p {
            font-size: 36px;
            margin: 0;
        }

        @media (max-width: 768px) {
            .dash-content .boxes .box {
                width: calc(50% - 10px);
            }
        }

        @media (max-width: 480px) {
            .dash-content .boxes .box {
                width: 100%;
            }
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="startpage.php">Home</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php
include('admin_sidebar.php');
?>

<div class="content">
    <div class="container">
        <h1 class="text-center mb-5">Dashboard</h1>
        <div class="dash-content">
            <div class="boxes">
                <div class="box">
                    <h5>MCA Records</h5>
                    <p><span id="mca_count">0</span></p>
                </div>
                <div class="box">
                    <h5>B-Tech Records</h5>
                    <p><span id="btech_count">0</span></p>
                </div>
                <div class="box">
                    <h5>M-Tech Records</h5>
                    <p><span id="mtech_count">0</span></p>
                </div>
                <div class="box">
                    <h5>Faculty Records</h5>
                    <p><span id="faculty_count">0</span></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
function fetchCounts() {
    $.ajax({
        url: 'fetch_counts.php',
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            $('#mca_count').text(data.mca_count);
            $('#btech_count').text(data.btech_count);
            $('#mtech_count').text(data.mtech_count);
            $('#faculty_count').text(data.faculty_count);
        },
        error: function(error) {
            console.log('Error fetching counts:', error);
        }
    });
}

$(document).ready(function() {
    fetchCounts(); // Initial fetch
    setInterval(fetchCounts, 5000); // Fetch counts every 5 seconds
});
</script>

</body>
</html>
