<?php
require('db.php');

// Check if the delete ID is set in the URL
if(isset($_GET['id'])) {
    // Get the ID to be deleted
    $id = $_GET['id']; 

    // Check if there are related records in the student_feedbacks table
    $check_query = "SELECT COUNT(*) AS count FROM student_feedbacks WHERE faculty_id='$id'";
    $check_result = mysqli_query($con, $check_query);
    $row = mysqli_fetch_assoc($check_result);
    $feedback_count = $row['count'];

    // If there are related records in student_feedbacks, delete them first
    if ($feedback_count > 0) {
        $delete_feedback_query = "DELETE FROM student_feedbacks WHERE faculty_id='$id'";
        mysqli_query($con, $delete_feedback_query) or die(mysqli_error($con));
    }

    // Now, delete the faculty record
    $del_query = "DELETE FROM admin_faculty WHERE id='$id'";
    mysqli_query($con, $del_query) or die(mysqli_error($con));

    // Redirect to the same page after deletion
    header("Location: admin_facultyview.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="style.css" />
<style>
/* style.css */

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
}

.form {
    width: 100%;
    margin: 50px auto;
    padding: 20px;
    background: #fff;
    border-radius: 5px;
    box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
}

.form h2 {
    text-align: center;
    margin-bottom: 20px;
}

.form p {
    text-align: right;
    margin-bottom: 20px;
}

.form a {
    text-decoration: none;
    color: #333;
    margin-left: 10px;
}

table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 5px;
    margin-top: 20px;
}

table th, table td {
   
    text-align: center;
    border: 1px solid #333; /* Dark border */
}

table th {
    background-color: lightsteelblue;
    color: black;
    font-size:16px;
}
table td {
    
    font-size:15px;
}

.header {
    text-align: right;
    margin-bottom: 20px;
}

.header a {
    text-decoration: none;
    color: #333;
    margin-left: 10px;
}

.header a:hover {
    color: #007bff; /* Change color on hover */
}

</style>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/Adminform.css" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_faculty.php">Add Faculty</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="startpage.php">Home</a>
                </li>
            </ul>
        </div>
    </div>
</nav><br>
<?php
include('admin_sidebar.php');
?>
 <div class="content">
        <div class="container">
            <div class="glass-card">
<h2 align="center" >Faculty Details</h2>

<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th rowspan="2"><strong>S.No</strong></th>
<th rowspan="2"><strong>Faculty Name</strong></th>
<th rowspan="2"><strong>Faculty ID</strong></th>
<th rowspan="2"><strong>Email</strong></th>
<th rowspan="2"><strong>Phone Number</strong></th>
<th rowspan="2"><strong>Semester Type</strong></th>
<th rowspan="2"><strong>Semester</strong></th>
<th colspan="3"><strong>Hour</th>
<th rowspan="2"><strong>Edit</strong></th>
<th rowspan="2"><strong>Delete</strong></th>
</tr>
<tr>
<th><strong>Class</strong></th>
<th><strong>Subject</strong></th>
<th><strong>Subject Code</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="SELECT * FROM admin_faculty ORDER BY id DESC;";
$result = mysqli_query($con, $sel_query);
while($row = mysqli_fetch_assoc($result)) { 
    $classList = [$row["class_1"], $row["class_2"], $row["class_3"]];
    $subjectList = [$row["subject_1"], $row["subject_2"], $row["subject_3"]];
    $subjectCodeList = [$row["subjectcode_1"], $row["subjectcode_2"], $row["subjectcode_3"]];
    foreach ($classList as $index => $class) {
?>

<tr>
<?php if ($index === 0) { ?>
<td align="center" rowspan="3"><?php echo $count; ?></td>
<td align="center" rowspan="3"><?php echo $row["facultyname"]; ?></td>
<td align="center" rowspan="3"><?php echo $row["facultyid"]; ?></td>
<td align="center" rowspan="3"><?php echo $row["email"]; ?></td>
<td align="center" rowspan="3"><?php echo $row["phoneno"]; ?></td>
<td align="center" rowspan="3"><?php echo $row["semester"]; ?></td>
<td align="center" rowspan="3"><?php echo $row["semestergrp"]; ?></td>
<?php } ?>
<td align="center"><?php echo $class; ?></td>
<td align="center"><?php echo $subjectList[$index]; ?></td>
<td align="center"> <?php echo $subjectCodeList[$index]; ?></td>
<?php if ($index === 0) { ?>
<td align="center" rowspan="3">
<a href="admin_faculty_edit.php?id=<?php echo $row["id"]; ?>">Edit</a>
</td>
<td align="center" rowspan="3">
<a href="admin_facultyview.php?id=<?php echo $row["id"]; ?>">Delete</a>
</td>
<?php } ?>
</tr>
<?php } $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
