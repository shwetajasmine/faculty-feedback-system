<?php
require('db.php');

// Initialize the error message variable
$error_message = '';

// If form submitted, check and validate login credentials.
if (isset($_POST['submit'])) {
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($con, $username);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($con, $password);

    // Check if username and password match admin_login table
    $query = "SELECT * FROM `admin_login` WHERE username='$username' and password='" . md5($password) . "'";
    $result = mysqli_query($con, $query) or die(mysqli_error($con));
    $rows = mysqli_num_rows($result);
    if ($rows == 1) {
        // Redirect to admin dashboard or any other page on successful login
        header("Location: admin_dashboard.php");
        exit();
    } else {
        // Set the error message
        $error_message = "Username/password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .error {
            color: red;
            font-size: 0.8em;
        }
        body {
            font-family: 'Roboto', sans-serif !important;
            height: 100vh;
            color: #3a3e42 !important;
        }
        .shadow-lg {
            box-shadow: 0 1rem 3rem rgb(211 103 202 / 40%) !important;
        }
        .AppForm .AppFormLeft h1 {
            font-size: 35px;
        }
        .AppForm .AppFormLeft input:focus {
            border-color: #ced4da;
        }
        .AppForm .AppFormLeft input::placeholder {
            font-size: 15px;
        }
        .AppForm .AppFormLeft i {
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
        }
        .AppForm .AppFormLeft a {
            color: #3a3e42;
        }
        .AppForm .AppFormLeft button {
            background: linear-gradient(45deg, #d268cc, #a952a3);
            border-radius: 30px;
        }
        .AppForm .AppFormLeft p span {
            color: #007bff;
        }
        .AppForm .AppFormRight {
            background-image: url('assets/admin.jpg');
            height: 450px;
            background-size: cover;
            background-position: center;
            box-shadow: -17px 4px 15px -3px rgba(0, 0, 0, 0.1);
        }
        .AppForm .AppFormRight:after {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
        }
        .AppForm .AppFormRight h2 {
            z-index: 1;
        }
        .AppForm .AppFormRight h2::after {
            content: "";
            position: absolute;
            width: 100%;
            height: 2px;
            background-color: #fff;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
        }
        .AppForm .AppFormRight p {
            z-index: 1;
        }
        .btn-success:hover {
            color: black;
            transition: 0.5s ease;
        }
        .btn-secondary {
            color: white;
            background-color: #385a64 !important;
            border-color: #6c757d;
        }
        .btn-secondary a {
            color: white !important;
            text-decoration: none;
        }
        .btn-secondary a:hover {
            color: white;
            transition: 0.5s ease;
        }
    </style>
</head>
<body>
<div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-md-9">
                <div class="AppForm shadow-lg">
                    <div class="row">
                        <div class="col-md-6 d-flex justify-content-center align-items-center">
                            <div class="AppFormLeft">
                                <h1 class="mb-4">Admin Login</h1>

                
                    <form name="login" action="" method="post" id="loginForm">
                    <div class="form-group">
                                        <input type="text" name="username" id="username" class="form-control" placeholder="Username" required />
                                        <span id="usernameError" class="error"></span>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="password" id="password" class="form-control" placeholder="Password" required />
                                        <span id="passwordError" class="error"></span>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" name="submit" class="btn btn-success btn-block shadow border-0 py-2">Login</button>
                                    </div>
                                    <?php if (!empty($error_message)) { ?>
                                        <div class="alert alert-danger">
                                            <?php echo $error_message; ?>
                                        </div>
                                    <?php } ?>
                                </form>
                                <div class="btn btn-secondary btn-block shadow border-0 py-2" style="border-radius:30px">
                                    <a href="admin_registration.php">Register</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="AppFormRight position-relative d-flex justify-content-center flex-column align-items-center text-center p-5 text-white"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    
    $(document).ready(function() {
        // Function to validate login form
        $('#loginForm').on('submit', function() {
            var username = $('#username').val();
            var password = $('#password').val();
            var usernameError = $('#usernameError');
            var passwordError = $('#passwordError');
            var valid = true;

            // Validate username
            if (!username) {
                usernameError.text("Username is required");
                valid = false;
            } else {
                usernameError.text("");
            }

            // Validate password
            if (!password) {
                passwordError.text("Password is required");
                valid = false;
            } else if (!validatePassword(password)) {
                passwordError.text("Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character, and be at least 8 characters long.");
                valid = false;
            } else {
                passwordError.text("");
            }

            return valid;
        });

        // Function to validate password
        function validatePassword(password) {
            var regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,}$/;
            return regex.test(password);
        }
    });
</script>
</body>
</html>
