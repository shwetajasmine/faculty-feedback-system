<?php
require('db.php');

$status = '';
$faculty_result = false; // Initialize $faculty_result variable
$show_form = true; // Initialize a variable to control whether to show the form or not

// Check if form is submitted
if(isset($_POST['new']) && $_POST['new'] == 1){
    $regno = $_POST['regno']; // Get registration number entered by the student

    // Check if the student is from MCA class
    $select_mca_query = "SELECT * FROM MCA WHERE regno = '$regno'";
    $mca_result = mysqli_query($con, $select_mca_query);
    $mca_row = mysqli_fetch_assoc($mca_result);

    if($mca_row) {
        // If student belongs to MCA class, fetch MCA student details
        $class = $mca_row['class'];
        $select_faculty_query = "SELECT * FROM admin_faculty WHERE class_1 = '$class'";
        $faculty_result = mysqli_query($con, $select_faculty_query);
        
        // Prepare status message with MCA student and faculty details
        $status .= "Name: {$mca_row['name']}<br>";
        $status .= "Class: MCA<br>";
        $status .= "Register Number: $regno<br>";
        $status .= "Email: {$mca_row['email']}<br>";
        $status .= "Semester: {$mca_row['semester']}<br>";
        $status .= "Phone Number: {$mca_row['phoneno']}<br>";

        // Set $show_form to false to hide the form
        $show_form = false;
    } else {
        // Check if the student is from B-Tech class
        $select_btech_query = "SELECT * FROM B_Tech WHERE regno = '$regno'";
        $btech_result = mysqli_query($con, $select_btech_query);
        $btech_row = mysqli_fetch_assoc($btech_result);

        if($btech_row) {
            // If student belongs to B-Tech class, fetch B-Tech student details
            $class = $btech_row['class'];
            $select_faculty_query = "SELECT * FROM admin_faculty WHERE class_2 = '$class' OR class_3 = '$class'";
            $faculty_result = mysqli_query($con, $select_faculty_query);
            
            // Prepare status message with B-Tech student details
           
            $status .= "Name: {$btech_row['name']}<br>";
            $status .= "Class: B-Tech<br>";
            $status .= "Register Number: $regno<br>";
            $status .= "Email: {$btech_row['email']}<br>";
            $status .= "Semester: {$btech_row['semester']}<br>";
            $status .= "Phone Number: {$btech_row['phoneno']}<br>";
           

            // Set $show_form to false to hide the form
            $show_form = false;
        } else {
            // Check if the student is from M-Tech class
            $select_mtech_query = "SELECT * FROM M_Tech WHERE regno = '$regno'";
            $mtech_result = mysqli_query($con, $select_mtech_query);
            $mtech_row = mysqli_fetch_assoc($mtech_result);

            if($mtech_row) {
                // If student belongs to M-Tech class, fetch M-Tech student details
                $class = $mtech_row['class'];
                $select_faculty_query = "SELECT * FROM admin_faculty WHERE class_3 = '$class'";
                $faculty_result = mysqli_query($con, $select_faculty_query);
                
                // Prepare status message with M-Tech student details
               
                $status .= "Name: {$mtech_row['name']}<br>";
                $status .= "Class: M-Tech<br>";
                $status .= "Register Number: $regno<br>";
                $status .= "Email: {$mtech_row['email']}<br>";
                $status .= "Semester: {$mtech_row['semester']}<br>";
                $status .= "Phone Number: {$mtech_row['phoneno']}<br>";
               

                // Set $show_form to false to hide the form
                $show_form = false;
            } else {
                // If no matching class found, display error message
                $status = "No student found with the given registration number.";
                $faculty_result = false; // Set faculty_result to false to prevent accessing null array
            }
        }
    }
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Check if ratings, feedbacks, and class are set in the POST data
    if(isset($_POST['ratings']) && isset($_POST['feedbacks']) && isset($_POST['class'])) {
        
        // Sanitize input data
        $class = mysqli_real_escape_string($con, $_POST['class']);
        
        // Loop through each faculty's rating and feedback
        foreach ($_POST['ratings'] as $faculty_id => $rating) {
            
            // Sanitize input data
            $faculty_id = mysqli_real_escape_string($con, $faculty_id);
            $rating = mysqli_real_escape_string($con, $rating);
            $feedback = mysqli_real_escape_string($con, $_POST['feedbacks'][$faculty_id]);
            
            // Insert feedback into the database with class
            $insert_query = "INSERT INTO student_feedbacks (faculty_id, rating, feedback, class) VALUES ('$faculty_id', '$rating', '$feedback', '$class')";
            mysqli_query($con, $insert_query);
        }
        
        // Show success message
        header("Location:student_dashboardmsg.php");
    exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style></style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
        
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="student_login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-light text-light bg-dark" href="startpage.php">Homepage</a>
                    </li>
                    
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
    <div class="glassmorphism-card mt-4 p-4">
        <h2 class="mb-3">Student Details</h2>
        <!-- Student registration form -->
        <?php if($show_form): ?>
        <form method="post" action="" class="mt-4">
            <div class="form-group">
                <label for="regno">Registration Number:</label>
                <input type="text" name="regno" id="regno" class="form-control">
            </div>
            <input type="hidden" name="new" value="1">
            <input type="submit" value="Submit" class="btn btn-primary">
        </form>
        <?php endif; ?>
        <!-- Display student details -->
        <?php if(!empty($status)): ?>
            <div class="student-details p-3">
        <div class="card mt-4">
            <div class="card-body">
                <?php 
                    echo str_replace([":Name", ":Email", ":Semester", ":Phone Number", ":Class", ":Register Number"], ["<b>Name:</b>", "<b>Email:</b>", "<b>Semester:</b>", "<b>Phone Number:</b>", "<b>Class:</b>", "<b>Register Number:</b>"], $status);
                ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Display faculty details in a table -->
        <?php if($faculty_result && mysqli_num_rows($faculty_result) > 0): ?>
        <div class="glassmorphism-card mt-4 p-4">
            <h2 class="mb-3">Feedback Form</h2>
        <form method="post" action="">
            <input type="hidden" name="class" value="<?php echo $class; ?>">
            <table class="table table-bordered table-striped mt-2 border-dark">
                <thead class="thead-dark">
                    <tr align ="center">
                        <th>S.No</th>
                        <th>Subject</th>
                        <th>SubjectCode</th>
                        <th>Faculty Name</th>
                        <th>Rating</th>
                        <th>Feedback</th>
                        <th>Comment</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $serial_number = 1; // Initialize serial number counter
                    while($faculty_row = mysqli_fetch_assoc($faculty_result)):
                    ?>
                    <tr>
                        <td align="center"><?php echo $serial_number++; ?></td>
                        
                        <?php if ($class == 'MCA'): ?>
                            <td align="center"><?php echo $faculty_row['subject_1']; ?></td>
                        <?php elseif ($class == 'B-Tech'): ?>
                            <td align="center"><?php echo $faculty_row['subject_2']; ?></td>
                        <?php elseif ($class == 'M-Tech'): ?>
                            <td align="center"><?php echo $faculty_row['subject_3']; ?></td>
                        <?php endif; ?>

                        <?php if ($class == 'MCA'): ?>
                            <td align="center"><?php echo $faculty_row['subjectcode_1']; ?></td>
                        <?php elseif ($class == 'B-Tech'): ?>
                            <td align="center"><?php echo $faculty_row['subjectcode_2']; ?></td>
                        <?php elseif ($class == 'M-Tech'): ?>
                            <td align="center"><?php echo $faculty_row['subjectcode_3']; ?></td>
                        <?php endif; ?>

                        <td align="center"><?php echo $faculty_row['facultyname']; ?></td>
                        <td align="center">
                            <!-- Rating selection -->
                            <select name="ratings[<?php echo $faculty_row['id']; ?>]" class="form-control">
                                <option value="">Select Rating</option>
                                <?php for ($i = 1; $i <= 10; $i++): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                <?php endfor; ?>
                            </select>
                        </td>
                        
                        <td align="center">
                            <!-- Feedback input -->
                            <textarea name="feedbacks[<?php echo $faculty_row['id']; ?>]" rows="2" cols="50" placeholder=" Give your Feedback here" class="form-control"></textarea>
                        </td>
                        <td align="center">
                            <!-- Comment link -->
                            <a href="faculty_comment.php?faculty_id=<?php echo $faculty_row['id']; ?>" class="btn btn-primary">Comment</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <!-- Common submit button -->
            <div class="text-center mt-4">
                <?php if(isset($success_message)) echo "<div class='alert alert-success' role='alert'>$success_message</div>"; ?>
                <input type="submit" class="btn btn-primary">
            </div>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
