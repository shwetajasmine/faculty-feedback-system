<?php
require('db.php');

if (isset($_POST['submit'])) {
    $roll_no = stripslashes($_POST['roll_no']);
    $roll_no = mysqli_real_escape_string($con, $roll_no);
    $student_name = stripslashes($_POST['student_name']);
    $student_name = mysqli_real_escape_string($con, $student_name);

    $query = "SELECT * FROM `student_login` WHERE roll_no='$roll_no' AND student_name='$student_name'";
    $result = mysqli_query($con, $query);

    $rows = mysqli_num_rows($result);

    if ($rows == 1) {
        // Student login successful
        header("Location: student_dashboard.php"); // Redirect to student dashboard or wherever needed
        exit(); // Make sure to exit after header redirection
    } else {
        $error_message = "Incorrect Roll Number or Student Name. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Student Login</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="css/student_login.css" />
</head>
<body>
<section>
<div class="form-box">
    <div class="form-value">
        <?php
        if (isset($error_message)) {
            echo "<div class='alert alert-danger'>$error_message</div>";
        }
        ?>
        <form name="student-login" id="loginForm" action="" method="post" novalidate>
            <h2>Student Login</h2>
            <div class="inputbox">
                <ion-icon name="mail-outline"></ion-icon>
                <input type="text" class="form-control" name="roll_no" placeholder="Roll Number" required />
                <div class="invalid-feedback">Please enter your Roll No.</div>
            </div>
            <div class="inputbox">
                <ion-icon name="lock-closed-outline"></ion-icon>
                <input type="text" class="form-control" name="student_name" placeholder="Student Name" required />
                <div class="invalid-feedback">Please enter your Name.</div>
            </div>
            <div class="button mt-5">
                <input type="submit" class="btn btn-primary btn-block" name="submit" value="Login" />
            </div>
            <p class="text-center"><a href='student_registration.php'>Register Here</a></p>
        </form>
    </div>
</div>
</section>

<!-- Bootstrap JS (optional, only needed if you want to use Bootstrap JavaScript features) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // Add event listener to the form
    document.getElementById("loginForm").addEventListener("submit", function(event) {
        // Check if the form is valid
        if (this.checkValidity() === false) {
            event.preventDefault(); // Prevent form submission
            event.stopPropagation(); // Prevent event propagation
        }
        this.classList.add('was-validated'); // Add Bootstrap's validation classes
    }, false);
</script>
</body>
</html>
