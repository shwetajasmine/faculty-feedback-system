<?php
require('db.php');

// Check if a faculty is selected
if(isset($_POST['faculty_id'])) {
    $faculty_id = $_POST['faculty_id'];

    // Fetch faculty details
    $faculty_query = "SELECT * FROM admin_faculty WHERE id = '$faculty_id'";
    $faculty_result = mysqli_query($con, $faculty_query);
    $faculty_row = mysqli_fetch_assoc($faculty_result);

    // Fetch distinct classes related to the selected faculty from the database
    $class_query = "SELECT DISTINCT class1, class2, class3 FROM admin_faculty WHERE id = '$faculty_id'";
    $class_result = mysqli_query($con, $class_query);

    // Check for query execution errors
    if (!$class_result) {
        // Handle the error, for example:
        die("Error fetching classes for the selected faculty: " . mysqli_error($con));
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Select Class</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="faculty_dashboard.php">Choose Faculty</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="startpage.php">Homepage</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="faculty_rating.php">Rating</a>
                </li>
            </ul>
        </div>
    </div>
</nav><br>
    <div class="container">
        <h2 class="mt-4">Select Class for <?php echo $faculty_row['facultyname']; ?></h2>
        
        <!-- Class selection form -->
        <form method="post" action="">
            <input type="hidden" name="faculty_id" value="<?php echo $faculty_id; ?>">
            <div class="form-group">
                <label for="class_id">Select Class:</label>
                <select name="class_id" id="class_id" class="form-control">
                    <?php while($class_row = mysqli_fetch_assoc($class_result)): ?>
                        <?php foreach($class_row as $class): ?>
                            <?php if(!empty($class)): ?>
                                <option value="<?php echo $class; ?>"><?php echo $class; ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endwhile; ?>
                </select>
            </div>
            <input type="submit" class="btn btn-primary" value="View Feedback">
        </form>

        <!-- Feedback display -->
        <?php 
        // Check if feedback_result is a valid mysqli_result object
        if(isset($_POST['class_id'])) {
            $class_id = $_POST['class_id'];

            // Fetch feedback for the selected faculty and class
            $feedback_query = "SELECT * FROM student_feedbacks WHERE faculty_id = '$faculty_id' AND class = '$class_id'";
            $feedback_result = mysqli_query($con, $feedback_query);

            // Check for query execution errors
            if (!$feedback_result) {
                // Handle the error, for example:
                die("Error fetching feedback data: " . mysqli_error($con));
            }

            // Calculate total feedbacks, total rating, and average rating
            $feedback_count = mysqli_num_rows($feedback_result);
            $total_rating = 0;
            while ($row = mysqli_fetch_assoc($feedback_result)) {
                $total_rating += $row['rating'];
            }
            $average_rating = $feedback_count > 0 ? $total_rating / $feedback_count : 0;
            ?>

            <!-- Display total rating and average rating -->
            <div class="card mt-4">
                <div class="card-body">
                    <h5 class="card-title">Total Feedbacks: <?php echo $feedback_count; ?></h5>
                    <h5 class="card-title">Total Rating: <?php echo $total_rating; ?></h5>
                    <h5 class="card-title">Average Rating: <?php echo number_format($average_rating, 2); ?></h5>
                </div>
            </div>

            <?php if(mysqli_num_rows($feedback_result) > 0): ?>
                <table class="table table-bordered table-striped mt-2 border-dark">
                    <thead class="thead-dark">
                        <tr align="center">
                            <th>S.No</th>
                            <th>Rating</th>
                            <th>Feedback</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        mysqli_data_seek($feedback_result, 0); // Resetting the pointer to the beginning of the result set
                        $serial_number = 1; // Initialize serial number counter
                        while($feedback_row = mysqli_fetch_assoc($feedback_result)):
                        ?>
                        <tr>
                            <td align="center"><?php echo $serial_number++; ?></td>
                            <td align="center"><?php echo $feedback_row['rating']; ?></td>
                            <td><?php echo $feedback_row['feedback']; ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info" role="alert">No feedback available for this faculty and class.</div>
            <?php endif;
        } ?>
    </div>
</body>
</html>

<?php
}
?>
