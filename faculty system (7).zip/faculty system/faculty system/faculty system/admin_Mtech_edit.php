<?php
require('db.php');
$id=$_REQUEST['id'];
$query = "SELECT * from M_Tech where id='".$id."'"; 
$result = mysqli_query($con, $query) or die(mysqli_error($con));
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>M Tech Form</title>
<!-- Bootstrap CSS -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/Adminform.css" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_MCA.php">MCA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_Btech.php">B_Tech</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_Mtech.php">M_Tech</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="admin_dashboard.php">Dashboard</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php
include('admin_sidebar.php');
?>
<div class="content">
        <div class="container">
            <div class="glass-card">
    <form class="mt-3" name="form" method="post" action=""> 
        <input type="hidden" name="new" value="1" />
<h1>M Tech Update Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];
$name =$_REQUEST['name'];
    $class = $_REQUEST['class'];
    $regno = $_REQUEST['regno'];
    $email = $_REQUEST['email'];
    $gender = $_REQUEST['gender'];
    $date_of_birth = $_REQUEST['date_of_birth'];
    $phoneno = $_REQUEST['phoneno'];
    $semester = $_REQUEST['semester'];
    $course_id = $_REQUEST['course_id'];
$update="update M_Tech set name='".$name."',
class='".$class."', regno='".$regno."',
email='".$email."',gender='".$gender."',date_of_birth='".$date_of_birth."', phoneno='".$phoneno."', semester='".$semester."', course_id='".$course_id."' where id='".$id."'";
mysqli_query($con, $update) or die(mysqli_error($con));
$status = "Record Updated Successfully. </br></br>
<a href='admin_Mtech.php'>View Updated Record</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}
else {
?>
<div>
<form class="mt-3" name="form" method="post" action=""> 
        <input type="hidden" name="new" value="1" />
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="Enter Name" required value="<?php echo $row['name'];?>" />
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="class" placeholder="Enter Class" required value="<?php echo $row['class'];?>" />
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="regno" placeholder="Enter Register Number" required value="<?php echo $row['regno'];?>" /> 
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Enter Email" required value="<?php echo $row['email'];?>" /> 
        </div>
        <div class="form-group">
    <select class="form-control" name="gender" id="gender">
        <option value="0" selected>Select Gender</option>
        <option value="<?php echo isset($row['Men']) ? htmlspecialchars($row['Men']) : 'Men'; ?>">Men</option>
        <option value="<?php echo isset($row['Female']) ? htmlspecialchars($row['Female']) : 'Female'; ?>">Female</option>
    </select>
</div>
        <div class="form-group">
            <input type="date" class="form-control" name="date_of_birth" placeholder="Enter Date Of Birth" required value="<?php echo $row['date_of_birth'];?>" /> 
         </div>
        <div class="form-group">
            <input type="text" class="form-control" name="phoneno" placeholder="Enter Phone Number" required value="<?php echo $row['phoneno'];?>" /> 
        </div>
        <div class="form-group">
                    <select class="form-control" name="semester" id="semester" required>
                        <option value="0">Select Semester</option>
                        <?php
                        for ($i = 1; $i <= 4; $i++) {
                            $selected = ($row['semester'] == $i) ? 'selected' : '';
                            echo "<option value='$i' $selected>$i</option>";
                        }
                        ?>
                    </select>
                </div>
        <div class="form-group">
            <select class="form-control" name="course_id" id="course_id">
                <option value="">Select Course</option>
                <?php
                $course_query = "SELECT Course_id FROM course_mtech";
                $course_result = mysqli_query($con, $course_query);
                while($course_row = mysqli_fetch_assoc($course_result)) {
                    $selected = ($row['course_id'] == $course_row['course_id']) ? 'selected' : '';
                    echo "<option value='" . $course_row['Course_id'] . "' $selected>" . $course_row['Course_id'] . "</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

<?php } ?>
</div>
</div>
</body>
</html>
