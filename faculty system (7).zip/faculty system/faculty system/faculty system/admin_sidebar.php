<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>Admin</title>
  
  <!-- Material Design Icons CSS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.min.css" />
  
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <style>
     body  {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}
    @media screen and (max-width: 991px) {
        .sidebar-offcanvas {
            position: fixed;
            max-height: calc(100vh - 70px);
            top: 70px;
            bottom: 0;
            overflow: auto;
            right: -260px;
            -webkit-transition: all 0.25s ease-out;
            transition: all 0.25s ease-out;
        }
    }

    .sidebar {
        min-height: calc(100vh - 70px);
        background: linear-gradient(to bottom, #e6e5f2, #4599cd);
        font-family: "Rubik", sans-serif;
        padding: 0;
        width: 260px;
        z-index: 11;
        transition: width 0.25s ease, background 0.25s ease;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        overflow-y: auto;
    }

    .sidebar .nav-item {
        width: 100%;
    }

    .sidebar .nav-link {
        display: flex;
        align-items: center;
        padding: 15px 20px;
        color: black;
        text-decoration: none;
        transition: background-color 0.3s, padding-left 0.3s;
            font-size: 18px;
    font-weight: 400;
    font-family: 'Poppins', sans-serif;
 
    }

    .sidebar .nav-link:hover,
    .sidebar .nav-link.active {
        background-color: #495057;
        color: white;
        padding-left: 25px;
    }

    .sidebar .nav-link .menu-icon {
        margin-right: 25px;
        color: #0d47a1; /* Dark blue icon color */
    }

    .sidebar-brand-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 10px 0;
        border-bottom: 1px solid #34495e;
    }

    .sidebar-brand {
        color: black;
        font-size: 24px;
        font-weight: bold;
        text-decoration: none;
    }

    .sidebar-brand-mini {
        display: none;
    }

    .content {
        margin-left: 260px;
        padding: 20px;
        flex: 1;
    }

    @media screen and (max-width: 991px) {
        .sidebar {
            width: 100%;
            height: auto;
            position: relative;
        }

        .sidebar .nav-item {
            display: inline-block;
            width: auto;
        }

        .content {
            margin-left: 0;
        }
    }
  </style>
</head>
<body>

<div class="container-scroller">
  <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <div class="text-center sidebar-brand-wrapper d-flex align-items-center">
      <a class="sidebar-brand brand-logo">ADMIN</a>
    </div>
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="admin_dashboard.php">
          <i class="mdi mdi-home menu-icon"></i>
          <span class="menu-title">Dashboard</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="admin_MCA.php">
        <i class="mdi mdi-account-plus menu-icon"></i>
          <span class="menu-title">Add Student</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="admin_facultyview.php">
        <i class="mdi mdi-school menu-icon"></i>
          <span class="menu-title">Add Faculty</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="admin_course_mca.php">
        <i class="mdi mdi-book-open menu-icon"></i>
          <span class="menu-title">Add Course</span>
        </a>
      </li>
    </ul>
  </nav>
  
  <div class="content">
   
  </div>
</div>

<script>
  // JavaScript to maintain active state on page load
  document.addEventListener('DOMContentLoaded', function() {
    var links = document.querySelectorAll('.nav-link');
    links.forEach(function(link) {
      if (link.href === window.location.href) {
        link.classList.add('active');
      }
      link.addEventListener('click', function() {
        links.forEach(function(l) {
          l.classList.remove('active');
        });
        link.classList.add('active');
      });
    });
  });
</script>

</body>
</html>
