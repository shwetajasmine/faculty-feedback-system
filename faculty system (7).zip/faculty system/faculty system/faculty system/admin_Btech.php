<?php
require('db.php');
$status = "";
if(isset($_POST['new']) && $_POST['new']==1){
    $name = $_REQUEST['name'];
    $class = $_REQUEST['class'];
    $regno = $_REQUEST['regno'];
    $email = $_REQUEST['email'];
    $gender = $_REQUEST['gender'];
    $date_of_birth = $_REQUEST['date_of_birth'];
    $phoneno = $_REQUEST['phoneno'];
    $semester = $_REQUEST['semester'];
    $course_id = $_REQUEST['course_id']; // Add course_id variable
    
    $ins_query = "INSERT INTO B_Tech (`name`, `class`, `regno`, `email`,`gender`, `date_of_birth`,`phoneno`, `semester`, `course_id`) 
                  VALUES ('$name', '$class', '$regno', '$email','$gender','$date_of_birth', '$phoneno', '$semester', '$course_id')";
    mysqli_query($con, $ins_query) or die(mysqli_error($con));
    $status = "New Record Inserted Successfully.</br></br>";
}

if(isset($_GET['id'])) {
    $id = $_GET['id']; 
    $del_query = "DELETE FROM B_Tech WHERE id='$id'";
    mysqli_query($con, $del_query) or die(mysqli_error($con));
    header("Location: admin_Btech.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>B Tech Form</title>
<!-- Bootstrap CSS -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<link rel="stylesheet" href="css/Adminform.css" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_MCA.php">MCA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_Btech.php">B_Tech</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_Mtech.php">M_Tech</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="startpage.php">Home</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php
include('admin_sidebar.php');
?>

<div class="content">
        <div class="container">
            <div class="glass-card">
    <h1>B Tech Form</h1>
    <form name="form" method="post" action=""> 
        <input type="hidden" name="new" value="1" />
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="Enter Name" required />
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="class" placeholder="Enter Class" required />
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="regno" placeholder="Enter Register Number" required />
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email" required />
            <span id="emailError" class="text-danger"></span> <!-- Error message placeholder -->
        </div>
        <div class="form-group">
            <select class="form-control" name="gender" id="gender">
                <option value="0" selected>Select Gender</option>
                <option value="Men">Men</option>
                <option value="Female">Female</option>
            </select>
        </div>
        <div class="form-group">
            <input type="date" class="form-control" name="date_of_birth" id="date_of_birth" placeholder="Enter date_of_birth" required />
            <span id="emailError" class="text-danger"></span>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="phoneno" id="phoneno" placeholder="Enter Phone Number" required />
            <span id="phoneError" class="text-danger"></span> <!-- Error message placeholder -->
        </div>
        <div class="form-group">
            <select class="form-control" name="semester" id="semester" >
            <option value="0" selected>Select Semester</option> <!-- Default value -->
            <option value="1">1</option>
                <option value="2">2</option> 
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
            </select>
        </div>
        <div class="form-group">
            <select class="form-control" name="course_id" id="course_id">
                <option value="">Select Course</option>
                <?php
                $course_query = "SELECT Course_id FROM Course_BTech"; // Change to the correct table name
                $course_result = mysqli_query($con, $course_query);
                while($row = mysqli_fetch_assoc($course_result)) {
                    echo "<option value='" . $row['Course_id'] . "'>" . $row['Course_id'] . "</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    <?php if(!empty($status)): ?>
    <div class="alert alert-success mt-3" role="alert">
        <?php echo $status; ?>
    </div>
    <?php endif; ?>
    <h1 class="mt-5 text-black">View Records</h1>
            <div class="table-responsive">
                <table class="table table-bordered mt-3">
                    <thead class="thead-dark">
                <tr>
                    <th>S.No</th>
                    <th>Name</th>
                    <th>Class</th>
                    <th>Register Number</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Semester</th>
                    <th>CourseId</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $count=1;
                $sel_query="SELECT * FROM B_Tech ORDER BY id DESC;";
                $result = mysqli_query($con,$sel_query);
                while($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $count; ?></td>
                    <td><?php echo $row["name"]; ?></td>
                    <td><?php echo $row["class"]; ?></td>
                    <td><?php echo $row["regno"]; ?></td>
                    <td><?php echo $row["email"]; ?></td>
                    <td><?php echo $row["phoneno"]; ?></td>
                    <td><?php echo $row["semester"]; ?></td>
                    <td><?php echo $row["Course_id"]; ?></td>
                    <td><a href="admin_Btech_edit.php?id=<?php echo $row["id"]; ?>" title="Edit"><i class="fas fa-edit"></i></a>
                    <a href="#" onclick="confirmDelete(<?php echo $row['id']; ?>)" class="btn text-danger" title="Delete"><i class="fas fa-trash-alt"></i></a></td>
                        </tr>
                    </tr>
                        <?php $count++; } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // Live email validation
$('#email').on('input', function() {
    var email = $(this).val();
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        $('#emailError').text('Invalid email format');
    } else {
        $('#emailError').text('');
    }
});

// Live phone number validation
$('#phoneno').on('input', function() {
    var phoneno = $(this).val();
    var phonePattern = /^\d{10}$/;
    if (!phonePattern.test(phoneno)) {
        $('#phoneError').text('Invalid phone number format');
    } else {
        $('#phoneError').text('');
    }
});

function confirmDelete(id) {
    if (confirm("Are you sure you want to delete this message?")) {
        window.location.href = 'admin_Btech.php?id=' + id;
    }
}
</script>

</body>
</html>
