<?php
require('db.php');
$status = "";

if(isset($_POST['new']) && $_POST['new'] == 1){
    $facultyname = $_POST['facultyname'];
    $facultyid = $_POST['facultyid'];
    $email = $_POST['email'];
    $phoneno = $_POST['phoneno'];
    $semester = $_POST['semester'];
    $semestergrp = $_POST['semestergrp'];
    $class_1 = $_POST['class_1'];
    $subject_1 = $_POST['subject_1'];
    $subjectcode_1 = $_POST['subjectcode_1'];
    $class_2 = $_POST['class_2'];
    $subject_2 = $_POST['subject_2'];
    $subjectcode_2 = $_POST['subjectcode_2'];
    $class_3 = $_POST['class_3'];
    $subject_3 = $_POST['subject_3'];
    $subjectcode_3 = $_POST['subjectcode_3'];
    
    $ins_query = "INSERT INTO admin_faculty
    (`facultyname`, `facultyid`, `email`, `phoneno`, `semester`, `semestergrp` ,`class_1`, `subject_1`, `subjectcode_1`, `class_2`, `subject_2`, `subjectcode_2`, `class_3`, `subject_3`, `subjectcode_3`)
    VALUES
    ('$facultyname', '$facultyid', '$email', '$phoneno', '$semester','$semestergrp', '$class_1', '$subject_1', '$subjectcode_1', '$class_2', '$subject_2', '$subjectcode_2', '$class_3', '$subject_3', '$subjectcode_3')";
    
    // Execute the query and check the result
    if(mysqli_query($con, $ins_query)){
        // Set success message if insertion is successful
        $status = "New Record Inserted Successfully.</br></br>";
    } else {
        // Set error message if insertion fails
        $status = "Error: " . $ins_query . "<br>" . mysqli_error($con);
    }
}

if(isset($_GET['id'])) {
    $id = $_GET['id']; 
    $del_query = "DELETE FROM admin_faculty WHERE id='$id'";
    mysqli_query($con, $del_query) or die(mysqli_error($con));
    header("Location: admin_faculty.php");
    exit();
}

?>


<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Faculty Form</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="css/Adminform.css" />
<style>
    /* Add custom styles here */
    .form-container {
        margin-top: 50px;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 10px;
    }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_facultyview.php">View Faculty</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="startpage.php">Home</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php
include('admin_sidebar.php');
?>

<div class="content">
        <div class="container">
            <div class="glass-card">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="form-container">
                <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
                    <a class="navbar-brand" href="#">Faculty Form</a>
                </nav>
                <?php if(!empty($status)): ?>
                <!-- Display success message if status is not empty -->
                <div class="alert alert-success" role="alert">
                    <?php echo $status; ?>
                </div>
                <?php endif; ?>
                <form name="form" method="post" action=""> 
                    <input type="hidden" name="new" value="1" />
                    <div class="form-group">
                        <input type="text" name="facultyname" class="form-control" placeholder="Enter Faculty Name" required />
                    </div>
                    <div class="form-group">
                        <input type="text" name="facultyid" class="form-control" placeholder="Enter Faculty ID" required />
                    </div>
                    <div class="form-group">
            <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email" required />
            <span id="emailError" class="text-danger"></span> <!-- Error message placeholder -->
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="phoneno" id="phoneno" placeholder="Enter Phone Number" required />
            <span id="phoneError" class="text-danger"></span> <!-- Error message placeholder -->
        </div>
                    <div class="form-group">
                        <select name="semester" id="semester" class="form-control" required>
                            <option value="">Choose the Semester type</option>
                            <option value="Odd Semester">Odd Semester</option>
                            <option value="Even Semester">Even Semester</option> 
                        </select>
                    </div>
                    <div class="form-group">
                        <select name="semestergrp" id="semestergrp" class="form-control" required>
                            <option value="">Choose the Semester</option>
                            <option value="I">I Semester</option>
                            <option value="II">II Semester</option> 
                            <option value="III">III Semester</option>
                            <option value="IV">IV Semester</option>
                            <option value="V">V Semester</option>
                            <option value="VI">VI Semester</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="class_1">Class 1:</label>
                            <select id="class_1" name="class_1" class="form-control">
                                <option value="">Class 1</option>
                                <option value="MCA">MCA</option>
                                <option value="B-tech">B-tech</option>
                                <option value="M-tech">M-tech</option>
                                <option value="None">None</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subject_1">Subject 1:</label>
                            <select id="subject_1" name="subject_1" class="form-control">
                                <option value="">Select the Subject</option>
                                <option value="Python">Python</option>
                                <option value="Internet Of Things">Internet Of Things</option>
                                <option value="Computer Networks">Computer Networks</option>
                                <option value="None">None</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subjectcode_1">SubjectCode 1:</label>
                            <select id="subjectcode_1" name="subjectcode_1" class="form-control">
                                <option value="">Select the SubjectCode</option>
                                <option value="PY102">PY102</option>
                                <option value="IOT34">IOT34</option>
                                <option value="CN457">CN457</option>
                                <option value="None">None</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="class_2">Class 2:</label>
                            <input type="text" id="class_2" name="class_2" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subject_2">Subject 2:</label>
                            <select id="subject_2" name="subject_2" class="form-control">
                                <option value="">Select the Subject</option>
                                <option value="Python">Python</option>
                                <option value="Internet Of Things">Internet Of Things</option>
                                <option value="Computer Networks">Computer Networks</option>
                                <option value="None">None</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subjectcode_2">SubjectCode 2:</label>
                            <select id="subjectcode_2" name="subjectcode_2" class="form-control">
                                <option value="">Select the SubjectCode</option>
                                <option value="PY102">PY102</option>
                                <option value="IOT34">IOT34</option>
                                <option value="CN457">CN457</option>
                                <option value="None">None</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="class_3">Class 3:</label>
                            <input type="text" id="class_3" name="class_3" class="form-control">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subject_3">Subject 3:</label>
                            <select id="subject_3" name="subject_3" class="form-control">
                                <option value="">Select the Subject</option>
                                <option value="Python">Python</option>
                                <option value="Internet Of Things">Internet Of Things</option>
                                <option value="Computer Networks">Computer Networks</option>
                                <option value="None">None</option>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="subjectcode_3">SubjectCode 3:</label>
                            <select id="subjectcode_3" name="subjectcode_3" class="form-control">
                                <option value="">Select the SubjectCode</option>
                                <option value="PY102">PY102</option>
                                <option value="IOT34">IOT34</option>
                                <option value="CN457">CN457</option>
                                <option value="None">None</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <input name="submit" type="submit" value="Submit" class="btn btn-primary" />
                       
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> <!-- Add this line for jQuery -->
<script>
// Live email validation
$('#email').on('input', function() {
    var email = $(this).val();
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        $('#emailError').text('Invalid email format');
    } else {
        $('#emailError').text('');
    }
});

// Live phone number validation
$('#phoneno').on('input', function() {
    var phoneno = $(this).val();
    var phonePattern = /^\d{10}$/;
    if (!phonePattern.test(phoneno)) {
        $('#phoneError').text('Invalid phone number format');
    } else {
        $('#phoneError').text('');
    }
});
</script>
</body>
</html>
