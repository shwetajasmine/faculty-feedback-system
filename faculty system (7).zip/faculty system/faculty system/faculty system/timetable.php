<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Timetable</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Student Timetable</h2>
    <table>
        <tr>
            <th>Time</th>
            <th>Monday</th>
            <th>Tuesday</th>
            <th>Wednesday</th>
            <th>Thursday</th>
            <th>Friday</th>
        </tr>
        <?php
            // Define timetable data
            $timetable = array(
                "9:00 AM" => array("Maths", "Physics", "", "", "English"),
                "10:00 AM" => array("English", "Chemistry", "", "Maths", "Physics"),
                "11:00 AM" => array("Physics", "Biology", "", "Chemistry", ""),
                "12:00 PM" => array("Lunch", "Lunch", "Lunch", "Lunch", "Lunch"),
                "1:00 PM" => array("", "", "Maths", "", "Biology"),
                "2:00 PM" => array("Chemistry", "", "Physics", "", "Chemistry"),
                "3:00 PM" => array("Biology", "", "English", "", "Maths"),
                "4:00 PM" => array("", "", "", "", "Extra-curricular")
            );

            // Loop through each time slot
            foreach ($timetable as $time => $subjects) {
                echo "<tr>";
                echo "<td>$time</td>";
                foreach ($subjects as $subject) {
                    echo "<td>$subject</td>";
                }
                echo "</tr>";
            }
        ?>
    </table>
</body>
</html>
