<?php
require('db.php');

// If form submitted, insert values into the database.
if (isset($_POST['submit'])) {
    // removes backslashes
    $roll_no = stripslashes($_POST['roll_no']);
    // escapes special characters in a string
    $roll_no = mysqli_real_escape_string($con, $roll_no);
    $course_id = stripslashes($_POST['course_id']);
    $course_id = mysqli_real_escape_string($con, $course_id);
    $student_name = stripslashes($_POST['student_name']);
    $student_name = mysqli_real_escape_string($con, $student_name);
    $trn_date = date("Y-m-d H:i:s");
    $query = "INSERT INTO `student_login` (roll_no, course_id, student_name, trn_date)
              VALUES ('$roll_no', '$course_id', '$student_name', '$trn_date')";
    $result = mysqli_query($con, $query);
    if ($result) {
        $success_message = "You are registered successfully. 
        <br>Click here to <a href='student_login.php'>Login</a>";
    } else {
        $error_message = "Registration failed. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Registration</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ionicons@5.5.0/dist/css/ionicons.min.css">
    <link rel="stylesheet" href="css/student_login.css" />

</head>
<body>
<section>
    <div class="form-box">
        <div class="form-value">
            <?php if (isset($success_message)) { ?>
                <div class="alert alert-success text-center"><?php echo $success_message; ?></div>
            <?php } elseif (isset($error_message)) { ?>
                <div class="alert alert-danger text-center"><?php echo $error_message; ?></div>
            <?php } ?>

            <form name="registration" action="" method="post" id="registrationForm" novalidate>
                <h2>Registration</h2>
                <div class="inputbox">
                    <ion-icon name="mail-outline"></ion-icon>
                    <input type="text" class="form-control" name="roll_no" id="roll_no" placeholder="Roll No" required>
                    <div class="invalid-feedback">Please enter your Roll No.</div>
                </div>
                <div class="inputbox">
                    <ion-icon name="lock-closed-outline"></ion-icon>
                    <input type="text" class="form-control" name="course_id" id="course_id" placeholder="Course Id" required>
                    <div class="invalid-feedback">Please enter a Course ID.</div>
                </div>
                <div class="inputbox">
                    <ion-icon name="lock-closed-outline"></ion-icon>
                    <input type="text" class="form-control" name="student_name" id="student_name" placeholder="Student Name" required>
                    <div class="invalid-feedback">Please enter your Student Name.</div>
                </div>
                <div class="button mt-5">
                    <input type="submit" class="btn btn-primary btn-block" name="submit" value="Register">
                </div>
            </form>
        </div>
    </div>
</section>

<!-- Bootstrap JS (optional, only needed if you want to use Bootstrap JavaScript features) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    // Add event listener to the form
    document.getElementById("registrationForm").addEventListener("submit", function(event) {
        // Check if the form is valid
        if (this.checkValidity() === false) {
            event.preventDefault(); // Prevent form submission
            event.stopPropagation(); // Prevent event propagation
        }
        this.classList.add('was-validated'); // Add Bootstrap's validation classes
    }, false);
</script>
</body>
</html>
