<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Comment</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            max-width: 600px;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">Faculty Comment Form</h2>
        <form method="post" action="submit_comment.php">
            <!-- List of questions with Yes/No options -->
            <div class="form-group">
                <label for="question1">Question 1: Was the faculty punctual to class?</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question1" id="question1_yes" value="Yes" checked>
                    <label class="form-check-label" for="question1_yes">Yes</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question1" id="question1_no" value="No">
                    <label class="form-check-label" for="question1_no">No</label>
                </div>
            </div>
            <div class="form-group">
                <label for="question2">Question 2: Had the faculty completed the syllabus on time?</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question2" id="question2_yes" value="Yes" checked>
                    <label class="form-check-label" for="question2_yes">Yes</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question2" id="question2_no" value="No">
                    <label class="form-check-label" for="question2_no">No</label>
                </div>
            </div>
            <div class="form-group">
                <label for="question3">Question 3: Were the tests conducted properly without inconvenience?</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question3" id="question3_yes" value="Yes" checked>
                    <label class="form-check-label" for="question3_yes">Yes</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question3" id="question3_no" value="No">
                    <label class="form-check-label" for="question3_no">No</label>
                </div>
            </div>
            <div class="form-group">
                <label for="question4">Question 4: Did the faculty give you enough practice sessions in the lab?</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question4" id="question4_yes" value="Yes" checked>
                    <label class="form-check-label" for="question4_yes">Yes</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question4" id="question4_no" value="No">
                    <label class="form-check-label" for="question4_no">No</label>
                </div>
            </div>
            <div class="form-group">
                <label for="question5">Question 5: Was the faculty available to solve your doubts?</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question5" id="question5_yes" value="Yes" checked>
                    <label class="form-check-label" for="question5_yes">Yes</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="question5" id="question5_no" value="No">
                    <label class="form-check-label" for="question5_no">No</label>
                </div>
            </div>
            <!-- Hidden fields to store faculty ID -->
            <input type="hidden" name="faculty_id" value="<?php echo $_GET['faculty_id']; ?>">
            <!-- Submit button -->
            <button type="submit" class="btn btn-primary btn-block">Submit</button>
        </form>
    </div>
</body>
</html>
