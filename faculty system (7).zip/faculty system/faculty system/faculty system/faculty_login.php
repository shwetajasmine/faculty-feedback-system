<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Faculty Login</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
            width: 500px;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        .form-container h1 {
            text-align: center;
            margin-bottom: 30px;
        }
        .form-container form {
            max-width: 400px;
            margin: 0 auto;
        }
        .form-container .btn {
            margin-top: 20px;
        }
        .form-group input[type="text"] {
            width: 100%;
        }
        .invalid-feedback {
            color: red;
        }
    </style>
</head>
<body>
    <?php
    require('db.php');

    if (isset($_POST['submit'])) {
        $faculty_id = stripslashes($_POST['faculty_id']);
        $faculty_id = mysqli_real_escape_string($con, $faculty_id);
        $faculty_name = stripslashes($_POST['faculty_name']);
        $faculty_name = mysqli_real_escape_string($con, $faculty_name);

        $query = "SELECT * FROM `faculty_login` WHERE faculty_id='$faculty_id' AND faculty_name='$faculty_name'";
        $result = mysqli_query($con, $query);

        $rows = mysqli_num_rows($result);

        if ($rows == 1) {
            header("Location: faculty_dashboard.php"); 
        } else {
            echo "<div class='form'>
                    <h3>Incorrect Faculty ID or faculty name. Please try again.</h3>
                    <br/>Click here to <a href='faculty_registration.php'>Register</a>
                  </div>";
        }
    }
    ?>
    <div class="container">
        <div class="form-container">
            <h1>Faculty Login</h1>
            <form name="faculty-login" id="loginForm" action="" method="post" novalidate>
                <div class="form-group">
                    <input type="text" class="form-control" name="faculty_id" placeholder="Faculty ID" required />
                    <div class="invalid-feedback">Please enter Faculty ID.</div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="faculty_name" placeholder="Faculty Name" required />
                    <div class="invalid-feedback">Please enter Faculty Name.</div>
                </div>
                <input type="submit" class="btn btn-primary btn-block" name="submit" value="Login" />
                <p class="text-center"> <a href='faculty_registration.php'>Register Here</a></p>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS (optional, only needed if you want to use Bootstrap JavaScript features) -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Add event listener to the form
        document.getElementById("loginForm").addEventListener("submit", function(event) {
            // Check if the form is valid
            if (this.checkValidity() === false) {
                event.preventDefault(); // Prevent form submission
                event.stopPropagation(); // Prevent event propagation
            }
            this.classList.add('was-validated'); // Add Bootstrap's validation classes
        }, false);
    </script>
</body>
</html>
