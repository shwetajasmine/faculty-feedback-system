-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2024 at 09:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faculty_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_faculty`
--

CREATE TABLE `admin_faculty` (
  `id` int(11) NOT NULL,
  `facultyname` varchar(255) NOT NULL,
  `facultyid` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phoneno` varchar(20) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `semestergrp` varchar(50) NOT NULL,
  `class_1` varchar(50) NOT NULL,
  `subject_1` varchar(100) NOT NULL,
  `subjectcode_1` varchar(50) NOT NULL,
  `class_2` varchar(50) NOT NULL,
  `subject_2` varchar(100) NOT NULL,
  `subjectcode_2` varchar(50) NOT NULL,
  `class_3` varchar(50) NOT NULL,
  `subject_3` varchar(100) NOT NULL,
  `subjectcode_3` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_faculty`
--

INSERT INTO `admin_faculty` (`id`, `facultyname`, `facultyid`, `email`, `phoneno`, `semester`, `semestergrp`, `class_1`, `subject_1`, `subjectcode_1`, `class_2`, `subject_2`, `subjectcode_2`, `class_3`, `subject_3`, `subjectcode_3`) VALUES
(1, 'PRANETHA', 'PraneethaCSE', 'praneetha@gmail.com', '8989807999', 'Even Semester ', 'II', 'MCA', 'Python', 'PY102', 'B-Tech', 'Internet Of Things', 'IOT34', 'None', 'None', 'None'),
(2, 'Geetha', 'GeethaCSE', 'geetha@gmail.com', '7857656540', 'Even Semester', 'VI', 'MCA', 'Python', 'PY102', 'B-Tech', 'Internet Of Things', 'IOT34', 'M-Tech', 'Computer Networks', 'CN457'),
(3, 'Kavitha', 'KavithaCSE', 'kavitha@gmail.com', '8676799999', 'Even Semester', 'IV', 'MCA', 'Computer Networks', 'CN457', 'B-Tech', 'Internet Of Things', 'IOT34', 'None', 'None', 'None'),
(11, 'Akila', 'AkilaCSE', 'akila@gmail.com', '7776666669', 'Even Semester', 'VI', 'MCA', 'Python', 'PY102', 'B-Tech', 'Computer Networks', 'CN457', 'M-Tech', 'Internet Of Things', 'IOT34'),
(12, 'Sarala', 'SaralaCSE', 'sarala@gmail.com', '8765423456', 'Even Semester', 'II', 'MCA', 'Python', 'PY102', 'B-Tech', 'Computer Networks', 'CN457', 'M-Tech', 'Internet Of Things', 'IOT34'),
(14, 'Manoharan', 'ManoharanCSE', 'manoharan@gmail.com', '6666655555', 'Even Semester', 'IV', 'MCA', 'Internet Of Things', 'IOT34', 'M-Tech', 'Computer Networks', 'CN457', 'B-Tech', 'Python', 'PY102'),
(16, 'Kalpana', 'KalpanaCSE', 'admin@gmail.com', '8754499034', 'Even Semester', 'IV', 'MCA', 'Python', 'IOT34', 'B-Tech', 'Internet Of Things', 'IOT34', 'M-Tech', 'Computer Networks', 'IOT34'),
(27, 'Pregna', 'PregnaCSE', 'pregna@gmail.com', '9899087992', 'Even Semester', 'IV', 'M-Tech', 'Internet Of Things', 'IOT34', 'B-Tech', 'Computer Networks', 'CN457', 'M-Tech', 'Internet Of Things', 'IOT34'),
(31, 'Karnakaren', 'KarnakarenCSE', 'karnakaren@gmail.com', '7678898765', 'Even Semester', 'IV', 'MCA', 'Internet Of Things', 'IOT34', 'M-Tech', 'Python', 'PY102', 'B-Tech', 'Computer Networks', 'CN457');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `email`, `password`, `trn_date`) VALUES
(13, 'Mohan', 'mohan@gmail.com', '079cac2d2792b6b1607922ff02b3e359', '2024-05-25 07:44:11'),
(14, 'Smith', 'smith@gmail.com', 'c436f2d72ce18c00c156103107eb9174', '2024-05-25 07:47:50'),
(15, 'Ravi', 'ravi@gmail.com', 'd947a59b6c35d59891e2461b90a9223b', '2024-05-25 18:58:07'),
(16, 'Admin', 'admin@gmail.com', '5960f4bb1ecb6b5cdd9d9700913fe69d', '2024-05-25 19:10:16');

-- --------------------------------------------------------

--
-- Table structure for table `b_tech`
--

CREATE TABLE `b_tech` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `regno` bigint(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phoneno` bigint(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `Course_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `b_tech`
--

INSERT INTO `b_tech` (`id`, `name`, `class`, `regno`, `email`, `gender`, `date_of_birth`, `phoneno`, `semester`, `Course_id`) VALUES
(2, 'Ajith', 'B-Tech', 2201507403, 'ajith@gmail.com', '', NULL, 7778889991, '3', 'BTECH03'),
(10, 'Mohan', 'B-Tech', 2201507428, 'Mohan@gmail.com', '', NULL, 8754499034, '5', 'BTECH05'),
(11, 'ann', 'B-Tech', 2201507404, 'ann@gmail.com', '', NULL, 4535354355, '4', 'BTECH04'),
(12, 'RohitSharma', 'B-Tech', 2201507450, 'rohit45@gmail.com', '', NULL, 9876543212, '3', 'BTECH03'),
(13, 'swati', 'B-Tech', 2201507408, 'praneetha@gmail.com', '', NULL, 8989807999, '5', 'BTECH05'),
(15, 'Selvam', 'B-Tech', 2201507434, 'selvam@gmail.com', '', NULL, 9876567807, '5', 'BTECH05'),
(16, 'Selvam', 'B-Tech', 2201507501, 'selvam@gmail.com', '', '2024-05-30', 9876543216, '4', 'BTECH08'),
(17, 'Selvam', 'B-Tech', 2201507444, 'selvam@gmail.com', 'Female', '2024-05-17', 9876543219, '4', 'BTECH08');

-- --------------------------------------------------------

--
-- Table structure for table `course_btech`
--

CREATE TABLE `course_btech` (
  `Course_id` varchar(20) NOT NULL,
  `Course_name` varchar(30) DEFAULT NULL,
  `Semester` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_btech`
--

INSERT INTO `course_btech` (`Course_id`, `Course_name`, `Semester`) VALUES
('BTECH01', 'BTECH', '1'),
('BTECH02', 'BTECH', '2'),
('BTECH03', 'BTECH', '3'),
('BTECH04', 'BTECH', '4'),
('BTECH05', 'BTECH', '5'),
('BTECH06', 'BTECH', '6'),
('BTECH07', 'BTECH', '7'),
('BTECH08', 'BTECH', '8');

-- --------------------------------------------------------

--
-- Table structure for table `course_mca`
--

CREATE TABLE `course_mca` (
  `Course_id` varchar(30) NOT NULL,
  `Course_name` varchar(30) NOT NULL,
  `semestergrp` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_mca`
--

INSERT INTO `course_mca` (`Course_id`, `Course_name`, `semestergrp`) VALUES
('MCA01', 'MCA', '1'),
('MCA02', 'MCA', '2'),
('MCA03', 'MCA', '3'),
('MCA04', 'MCA', '4');

-- --------------------------------------------------------

--
-- Table structure for table `course_mtech`
--

CREATE TABLE `course_mtech` (
  `Course_id` varchar(20) NOT NULL,
  `Course_name` varchar(30) DEFAULT NULL,
  `Semester` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_mtech`
--

INSERT INTO `course_mtech` (`Course_id`, `Course_name`, `Semester`) VALUES
('MTECH01', 'MTECH', '1'),
('MTECH02', 'MTECH', '2'),
('MTECH03', 'MTECH', '3'),
('MTECH04', 'MTECH', '4');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_login`
--

CREATE TABLE `faculty_login` (
  `id` int(11) NOT NULL,
  `faculty_id` varchar(50) NOT NULL,
  `faculty_name` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty_login`
--

INSERT INTO `faculty_login` (`id`, `faculty_id`, `faculty_name`, `trn_date`) VALUES
(1, '1001', 'Kavitha', '2024-03-05 17:13:24'),
(2, 'KavithaCSE', 'Kavitha', '2024-03-25 14:03:20'),
(3, 'MC023', 'Priya', '2024-04-17 18:49:41'),
(4, 'CS01', 'Priya', '2024-04-17 18:53:26'),
(5, 'CSE899', 'PRANEETHA', '2024-04-23 11:50:56'),
(6, 'CSE888', 'SWETHA', '2024-04-30 07:18:02'),
(7, 'CSE679', 'CENF', '2024-04-30 12:01:27'),
(8, 'CSE890', 'PRANEETHA', '2024-05-10 15:23:45'),
(9, 'CSE100', 'SARALA', '2024-05-13 13:38:49'),
(10, 'CSE890', 'PRANEETHA', '2024-05-13 13:41:04'),
(11, 'CSE890', 'PRANEETHA', '2024-05-13 13:42:17'),
(12, 'CSE890', 'PRANEETHA', '2024-05-13 13:42:53'),
(13, 'CSE890', 'PRANEETHA', '2024-05-13 13:44:08'),
(14, 'CSE890', 'PRANEETHA', '2024-05-13 13:44:24'),
(15, 'CSE709', 'Sarala', '2024-05-14 06:38:33'),
(16, 'CSE709', 'Sarala', '2024-05-14 06:38:59'),
(17, 'CSE777', 'Preetha', '2024-05-14 06:43:33'),
(18, 'CSE799', 'Preetha', '2024-05-14 07:03:23'),
(19, 'CSE300', 'Jain', '2024-05-15 12:30:50');

-- --------------------------------------------------------

--
-- Table structure for table `mca`
--

CREATE TABLE `mca` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `regno` bigint(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phoneno` bigint(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `Course_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mca`
--

INSERT INTO `mca` (`id`, `name`, `class`, `regno`, `email`, `gender`, `date_of_birth`, `phoneno`, `semester`, `Course_id`) VALUES
(2, 'Mohan', 'MCA', 2201507312, 'mohan@gmail.com', '', NULL, 9876511111, '1', 'MCA01'),
(6, 'Swetha', 'MCA', 2201507324, 'swetha13@gmail.com', '', NULL, 9876543216, '1', 'MCA01'),
(7, 'Vinodhini', 'MCA', 2201507328, 'vino@gmail.com', '', NULL, 2737878886, '2', 'MCA02'),
(8, 'Aravindhane', 'MCA', 2201507301, 'aravind@gmail.com', '', NULL, 3543546679, '3', 'MCA03'),
(29, 'swetha', 'MCA', 2201507325, 'swe@gmail.com', '', NULL, 9909023423, '2', 'MCA02'),
(33, 'Smith', 'MCA', 2201507323, 'smith@gmail.com', '', NULL, 9876543216, '2', 'MCA03'),
(38, 'Ravi', 'MCA', 2201507334, 'ravi@gmail.com', '', '2024-05-30', 9876543214, '3', 'MCA01'),
(39, 'Selvam', 'MCA', 2201507328, 'selvam@gmail.com', 'Men', '2024-05-15', 9876543216, '2', 'MCA02');

-- --------------------------------------------------------

--
-- Table structure for table `m_tech`
--

CREATE TABLE `m_tech` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `regno` bigint(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phoneno` bigint(50) NOT NULL,
  `semester` varchar(50) NOT NULL,
  `Course_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `m_tech`
--

INSERT INTO `m_tech` (`id`, `name`, `class`, `regno`, `email`, `gender`, `date_of_birth`, `phoneno`, `semester`, `Course_id`) VALUES
(3, 'Smith', 'M-Tech', 2201507502, 'smith@gmail.com', '', NULL, 98765434444, '3', 'MTECH03'),
(4, 'ann', 'M-Tech', 2201507312, 'swethaself02@gmail.com', '', NULL, 8989807999, '4', 'MTECH04'),
(5, ' Nivedha', 'M-Tech', 2201507503, 'nivedha@gmail.com', '', NULL, 6746745698, '2', 'MTECH02'),
(6, 'Pahal', 'M-Tech', 2201507520, 'yff@gmail.com', '', NULL, 4444655566, '2', 'MTECH02'),
(7, 'AjithaKumar', 'M-Tech', 2201507510, 'ajitha@gmail.com', '', NULL, 2737878886, '4', 'MTECH04'),
(8, 'Smith', 'M-Tech', 2201507534, 'smith@gmail.com', '', NULL, 9876543214, '1', 'MTECH02'),
(9, 'Smith', 'M-Tech', 2201507545, 'smith@gmail.com', '', '2024-05-20', 9876543219, '1', 'MTECH01'),
(10, 'Sam', 'M-Tech', 2201507324, 'sam@gmail.com', 'Men', '2024-05-30', 9876543219, '3', 'MTECH04');

-- --------------------------------------------------------

--
-- Table structure for table `student_feedbacks`
--

CREATE TABLE `student_feedbacks` (
  `id` int(11) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL,
  `facultyname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_feedbacks`
--

INSERT INTO `student_feedbacks` (`id`, `faculty_id`, `rating`, `feedback`, `class`, `facultyname`) VALUES
(20, 1, 10, 'best teaching', 'MCA', ''),
(28, 1, 4, 'excellent', 'MCA', ''),
(40, 11, 9, 'Conducting regular tests and assignments. Her teaching made us understand a lot of concepts easily.', 'MCA', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_login`
--

CREATE TABLE `student_login` (
  `id` int(11) NOT NULL,
  `roll_no` varchar(50) NOT NULL,
  `course_id` varchar(50) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_login`
--

INSERT INTO `student_login` (`id`, `roll_no`, `course_id`, `student_name`, `trn_date`) VALUES
(3, '2201507401', 'MBA', 'Rohit', '2024-03-06 20:16:42'),
(6, '2201507401', 'B-Tech', 'Selvam', '2024-03-30 13:04:31'),
(7, '2201507324', 'MCA', 'Swetha', '2024-03-30 13:06:07'),
(9, '2201507502', 'MTECH04', 'Monisha', '2024-04-17 19:02:27'),
(10, '2201507328', 'MCA01', 'Vinodhini', '2024-04-23 12:03:54'),
(17, '2201507303', 'MCA01', 'ASWIN', '2024-05-13 11:23:54'),
(18, '2201507404', 'MCA01', 'ARAVINDHANE', '2024-05-13 11:25:46'),
(30, '2201507328', 'MCA01', 'Vinodhini', '2024-05-13 11:37:07'),
(31, '2201507328', 'MCA01', 'Vinodhini', '2024-05-13 11:38:10'),
(36, '2201507324', 'MCA01', 'Swetha', '2024-05-13 11:43:03'),
(37, '2201507303', 'MCA01', 'ASWIN', '2024-05-13 11:43:11'),
(38, '2201507303', 'MCA01', 'ASWIN', '2024-05-13 11:44:51'),
(39, '2201507303', 'MCA01', 'ASWIN', '2024-05-13 11:44:51'),
(42, '22CS12', 'MCA01', 'ASWIN', '2024-05-13 11:47:10'),
(44, '22CS12', 'MCA01', 'ASWIN', '2024-05-13 11:47:48'),
(49, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 11:54:19'),
(50, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 11:54:34'),
(51, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 11:54:34'),
(52, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 11:56:44'),
(53, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 11:57:09'),
(54, '2201507328', 'MCA01', '', '2024-05-13 11:57:14'),
(55, '', '', '', '2024-05-13 11:57:16'),
(62, '2201507328', '', '', '2024-05-13 11:59:50'),
(63, '2201507328', '', '', '2024-05-13 12:00:06'),
(65, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:00:22'),
(67, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:01:34'),
(68, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:03:09'),
(69, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:03:15'),
(70, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:03:22'),
(71, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:04:43'),
(72, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:04:48'),
(73, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:05:17'),
(75, '2201507350', 'MCA', 'Rohit', '2024-05-13 12:14:40'),
(76, '2201507404', 'BTECH', 'ann', '2024-05-13 12:27:52'),
(77, '2201507503', 'MTECH', 'nivedha', '2024-05-13 12:35:13'),
(78, '2201507450', 'BTECH', 'RohitSharam', '2024-05-13 12:41:25'),
(79, '', '', '', '2024-05-13 12:50:06'),
(80, '', '', '', '2024-05-13 12:50:13'),
(81, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:53:13'),
(82, '2201507328', 'MCA01', 'ASWIN', '2024-05-13 12:53:17'),
(83, '', '', '', '2024-05-13 12:53:21'),
(84, '', '', '', '2024-05-13 12:55:02'),
(91, '2201507324', 'MCA01', 'Swetha', '2024-05-14 06:22:57'),
(92, '2201507373', 'MCA', 'Dhoni', '2024-05-14 06:34:28'),
(93, '2201507325', 'MCA', 'ASWIN', '2024-05-14 07:00:23'),
(94, '2201507321', 'MCA', 'Nitya', '2024-05-15 12:27:14'),
(95, '2201507321', 'MCA', 'Nitya', '2024-05-15 12:27:31'),
(96, '220150999', 'MCA', 'MIKE', '2024-05-15 12:28:17'),
(97, '2201507999', 'MCA', 'MIKE', '2024-05-15 12:29:27'),
(98, '2201507328', 'MCA01', 'Vinodhini', '2024-05-15 14:01:04'),
(99, '2201507333', 'MCA', 'Swetha', '2024-05-15 14:01:44'),
(102, '2201507724', 'MCA', 'Rohit', '2024-05-27 07:49:37'),
(104, '2201507312', 'MCA', 'Mohan', '2024-05-30 20:31:03'),
(105, '2201507311', 'MCA', 'BenStokes', '2024-05-30 20:35:41'),
(106, '2201507426', 'B-Tech', 'Mohan', '2024-05-30 20:45:12'),
(108, '2201507456', 'B-Tech', 'BenStokes', '2024-05-30 20:59:36'),
(110, '2201507457', 'B-Tech', 'BenStokes', '2024-05-30 21:00:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_faculty`
--
ALTER TABLE `admin_faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `b_tech`
--
ALTER TABLE `b_tech`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Course_id` (`Course_id`);

--
-- Indexes for table `course_btech`
--
ALTER TABLE `course_btech`
  ADD PRIMARY KEY (`Course_id`);

--
-- Indexes for table `course_mca`
--
ALTER TABLE `course_mca`
  ADD PRIMARY KEY (`Course_id`);

--
-- Indexes for table `course_mtech`
--
ALTER TABLE `course_mtech`
  ADD PRIMARY KEY (`Course_id`);

--
-- Indexes for table `faculty_login`
--
ALTER TABLE `faculty_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mca`
--
ALTER TABLE `mca`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Course_id` (`Course_id`);

--
-- Indexes for table `m_tech`
--
ALTER TABLE `m_tech`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Course_id` (`Course_id`);

--
-- Indexes for table `student_feedbacks`
--
ALTER TABLE `student_feedbacks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `faculty_id` (`faculty_id`);

--
-- Indexes for table `student_login`
--
ALTER TABLE `student_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_faculty`
--
ALTER TABLE `admin_faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `b_tech`
--
ALTER TABLE `b_tech`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `faculty_login`
--
ALTER TABLE `faculty_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `mca`
--
ALTER TABLE `mca`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `m_tech`
--
ALTER TABLE `m_tech`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student_feedbacks`
--
ALTER TABLE `student_feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `student_login`
--
ALTER TABLE `student_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `b_tech`
--
ALTER TABLE `b_tech`
  ADD CONSTRAINT `b_tech_ibfk_1` FOREIGN KEY (`Course_id`) REFERENCES `course_btech` (`Course_id`);

--
-- Constraints for table `mca`
--
ALTER TABLE `mca`
  ADD CONSTRAINT `mca_ibfk_1` FOREIGN KEY (`Course_id`) REFERENCES `course_mca` (`Course_id`);

--
-- Constraints for table `m_tech`
--
ALTER TABLE `m_tech`
  ADD CONSTRAINT `m_tech_ibfk_1` FOREIGN KEY (`Course_id`) REFERENCES `course_mtech` (`Course_id`);

--
-- Constraints for table `student_feedbacks`
--
ALTER TABLE `student_feedbacks`
  ADD CONSTRAINT `student_feedbacks_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `admin_faculty` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
