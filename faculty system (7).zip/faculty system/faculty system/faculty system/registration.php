<?php
require('db.php');

$success_message = ""; // Initialize the success message variable

if (isset($_POST['submit'])) {
    $role = $_POST['role'];

    switch ($role) {
        case 'admin':
            // Process admin registration
            $username = mysqli_real_escape_string($con, $_POST['username']);
            $email = mysqli_real_escape_string($con, $_POST['email']);
            $password = mysqli_real_escape_string($con, $_POST['password']);
            $query = "INSERT INTO `users` (username, password, email, role, trn_date)
                      VALUES ('$username', '" . md5($password) . "', '$email', '$role', NOW())";
            break;
        case 'student':
            // Process student registration
            $roll_no = mysqli_real_escape_string($con, $_POST['roll_no']);
            $course_id = mysqli_real_escape_string($con, $_POST['course_id']);
            $student_name = mysqli_real_escape_string($con, $_POST['student_name']);
            $query = "INSERT INTO `students` (role, roll_no, course_id, student_name, trn_date)
                      VALUES ('$role', '$roll_no', '$course_id', '$student_name', NOW())";
            break;
        case 'faculty':
            // Process faculty registration
            $faculty_id = mysqli_real_escape_string($con, $_POST['faculty_id']);
            $faculty_name = mysqli_real_escape_string($con, $_POST['faculty_name']);
            $query = "INSERT INTO `faculties` (role, faculty_id, faculty_name, trn_date)
                      VALUES ('$role', '$faculty_id', '$faculty_name', NOW())";
            break;
        default:
            // Handle unexpected case
            break;
    }

    if (!empty($query)) {
        $result = mysqli_query($con, $query);
        if ($result) {
            // Success message based on the role
            switch ($role) {
                case 'admin':
                    $success_message = "Admin registered successfully.";
                    break;
                case 'student':
                    $success_message = "Student registered successfully.";
                    break;
                case 'faculty':
                    $success_message = "Faculty registered successfully.";
                    break;
                default:
                    // Handle unexpected case
                    break;
            }
        } else {
            $success_message = "Registration failed. Please try again later.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Registration</title>
    <link rel="stylesheet" href="css/style.css" />
</head>
<body>
    <div class="form">
        <h1>Registration</h1>
        <?php if (!empty($success_message)) { ?>
            <div class="message"><?php echo $success_message; ?></div>
        <?php } ?>

        <form name="registration" action="" method="post">
            <!-- Dropdown for selecting role -->
            <select name="role" id="roleSelector" required>
                <option value="">Choose the registration form</option>
                <option value="admin">Admin</option>
                <option value="student">Student</option>
                <option value="faculty">Faculty</option>
            </select>

            <!-- Additional fields for admin registration -->
            <div id="adminFields" style="display: none;">
                <input type="text" name="username" placeholder="Username" required />
                <input type="email" name="email" placeholder="Email" required />
                <input type="password" name="password" placeholder="Password" required />
            </div>

            <!-- Additional fields for student registration -->
            <div id="studentFields" style="display: none;">
                <input type="text" name="roll_no" placeholder="Roll Number" />
                <input type="text" name="course_id" placeholder="Course ID" />
                <input type="text" name="student_name" placeholder="Student Name" />
                <?php if (!empty($success_message) && $role === 'student') { ?>
                    <div class="message"><?php echo $success_message; ?></div>
                <?php } ?>
            </div>

            <!-- Additional fields for faculty registration -->
            <div id="facultyFields" style="display: none;">
                <input type="text" name="faculty_id" placeholder="Faculty ID" />
                <input type="text" name="faculty_name" placeholder="Faculty Name" />
                <?php if (!empty($success_message) && $role === 'faculty') { ?>
                    <div class="message"><?php echo $success_message; ?></div>
                <?php } ?>
            </div>

            <input type="submit" name="submit" value="Register" />
        </form>
    </div>

    <script>
        // JavaScript to show/hide additional fields based on the selected role
        document.getElementById('roleSelector').addEventListener('change', function() {
            var role = this.value;
            document.getElementById('adminFields').style.display = role === 'admin' ? 'block' : 'none';
            document.getElementById('studentFields').style.display = role === 'student' ? 'block' : 'none'; 'none';
            document.getElementById('facultyFields').style.display = role === 'faculty' ? 'block' : 'none';
        });
    </script>
</body>
</html>
