<?php

require('db.php');
$status = "";

if(isset($_POST['new']) && $_POST['new'] == 1){
   
    $Course_id = $_REQUEST['Course_id'];
    $Course_name = $_REQUEST['Course_name']; // Change to lowercase
    $semestergrp = $_REQUEST['semestergrp'];
    
   
    $ins_query = "INSERT INTO course_mca( `Course_id`, `Course_name`, `semestergrp` ) 
                  VALUES ( '$Course_id', '$Course_name','$semestergrp')";
    mysqli_query($con, $ins_query) or die(mysqli_error($con));
    
    // Set the success message
    $status = "New Record Inserted Successfully.</br></br>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MCA Form</title>
<!-- Bootstrap CSS -->
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/Adminform.css" />
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
    
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_course_MCA.php">MCA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_course_Btech.php">B_Tech</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark mr-2" href="admin_course_Mtech.php">M_Tech</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn btn-outline-light text-light bg-dark" href="startpage.php">Home</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php
include('admin_sidebar.php');
?>
 <div class="content">
        <div class="container">
            <div class="glass-card">
    <h1 class="mt-5">MCA Form</h1>
    <!-- MCA Form -->
    <form class="mt-3" name="form" method="post" action=""> 
        <input type="hidden" name="new" value="1" />
        <div class="form-group">
            <input type="text" class="form-control" name="Course_id" placeholder="Enter courseId" required />
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="Course_name" placeholder="Enter Course Name" required />
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="semestergrp" placeholder="Enter Semester" required />
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>
    <!-- Success Message -->
    <?php if(!empty($status)): ?>
    <div class="alert alert-success mt-3" role="alert">
        <?php echo $status; ?>
    </div>
    <?php endif; ?>

   
<!-- Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
